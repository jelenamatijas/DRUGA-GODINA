﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using DokanNet;

namespace FileSystemTest
{
    class TestFS : IDokanOperations
    {
        Dictionary<string, byte[]> files = new Dictionary<string, byte[]>();
        HashSet<string> dirs = new HashSet<string>();

        public void Cleanup(string fileName, DokanFileInfo info)
        {

        }

        public void CloseFile(string fileName, DokanFileInfo info)
        {

        }

        public NtStatus CreateFile(string fileName, DokanNet.FileAccess access, FileShare share, FileMode mode, FileOptions options, FileAttributes attributes, DokanFileInfo info)
        {
            if (fileName == "\\")
                return NtStatus.Success;
            if (access == DokanNet.FileAccess.ReadAttributes && mode == FileMode.Open)
                return NtStatus.Success;
            if (mode == FileMode.CreateNew)
            {
                if (attributes == FileAttributes.Directory || info.IsDirectory)
                    dirs.Add(fileName);
                else if (!files.Keys.Contains(fileName))
                    files.Add(fileName, new byte[0]);
            }
            return NtStatus.Success;
        }

        public NtStatus DeleteDirectory(string fileName, DokanFileInfo info)
        {
            if (!info.IsDirectory)
                return DokanResult.Error;
            dirs.Remove(fileName);
            return DokanResult.Success;
        }

        public NtStatus DeleteFile(string fileName, DokanFileInfo info)
        {
            if (info.IsDirectory)
                return DokanResult.Error;
            files.Remove(fileName);
            return NtStatus.Success;
        }

        public NtStatus FindFiles(string fileName, out IList<FileInformation> files, DokanFileInfo info)
        {
            files = new List<FileInformation>();
            int pathCount = fileName.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Length;
            foreach (var x in dirs.Where(x => x.StartsWith(fileName) && x.Length > fileName.Length))
            {
                FileInformation fileInfo = new FileInformation();
                fileInfo.Attributes = FileAttributes.Directory;
                fileInfo.FileName = Path.GetFileName(x);
                files.Add(fileInfo);
            }
            foreach (var x in this.files.Where(x => x.Key.StartsWith(fileName) && x.Key.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Length == pathCount + 1))
            {
                FileInformation fileInfo = new FileInformation();
                fileInfo.FileName = Path.GetFileName(x.Key);
                fileInfo.Length = x.Value.Length;
                files.Add(fileInfo);
            }
            return NtStatus.Success;
        }

        public NtStatus FindFilesWithPattern(string fileName, string searchPattern, out IList<FileInformation> files, DokanFileInfo info)
        {
            files = new FileInformation[0];
            return DokanResult.NotImplemented;
        }

        public NtStatus FindStreams(string fileName, out IList<FileInformation> streams, DokanFileInfo info)
        {
            streams = new FileInformation[0];
            return DokanResult.NotImplemented;
        }

        public NtStatus FlushFileBuffers(string fileName, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus GetDiskFreeSpace(out long freeBytesAvailable, out long totalNumberOfBytes, out long totalNumberOfFreeBytes, DokanFileInfo info)
        {
            freeBytesAvailable = 500_000;
            totalNumberOfBytes = 100_000_000;
            totalNumberOfFreeBytes = 500_000;
            return NtStatus.Success;
        }

        public NtStatus GetFileInformation(string fileName, out FileInformation fileInfo, DokanFileInfo info)
        {
            if (dirs.Contains(fileName))
            {
                fileInfo = new FileInformation()
                {
                    FileName = Path.GetFileName(fileName),
                    Attributes = FileAttributes.Directory,
                    CreationTime = null,
                    LastWriteTime = null
                };
            }
            else if (files.ContainsKey(fileName))
            {
                byte[] file = files[fileName];
                fileInfo = new FileInformation()
                {
                    FileName = Path.GetFileName(fileName),
                    Length = file.Length,
                    Attributes = FileAttributes.Normal,
                    CreationTime = DateTime.Now,
                    LastWriteTime = DateTime.Now
                };
            }
            else
            {
                fileInfo = default(FileInformation);
                return NtStatus.Error;
            }
            return NtStatus.Success;
        }

        public NtStatus GetFileSecurity(string fileName, out FileSystemSecurity security, AccessControlSections sections, DokanFileInfo info)
        {
            security = null;
            return NtStatus.Error;
        }

        public NtStatus GetVolumeInformation(out string volumeLabel, out FileSystemFeatures features, out string fileSystemName, DokanFileInfo info)
        {
            volumeLabel = "TestFS";
            features = FileSystemFeatures.None;
            fileSystemName = string.Empty;
            return NtStatus.Success;
        }

        public NtStatus LockFile(string fileName, long offset, long length, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus Mounted(DokanFileInfo info)
        {
            return NtStatus.Success;
        }

        public NtStatus MoveFile(string oldName, string newName, bool replace, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus ReadFile(string fileName, byte[] buffer, out int bytesRead, long offset, DokanFileInfo info)
        {
            byte[] file = files[fileName];
            int i = 0;
            for (i = 0; i < file.Length && i < buffer.Length; ++i)
                buffer[i] = file[i];
            bytesRead = i;
            return NtStatus.Success;
        }

        public NtStatus SetAllocationSize(string fileName, long length, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus SetEndOfFile(string fileName, long length, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus SetFileAttributes(string fileName, FileAttributes attributes, DokanFileInfo info)
        {
            return NtStatus.Success;
        }

        public NtStatus SetFileSecurity(string fileName, FileSystemSecurity security, AccessControlSections sections, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus SetFileTime(string fileName, DateTime? creationTime, DateTime? lastAccessTime, DateTime? lastWriteTime, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus UnlockFile(string fileName, long offset, long length, DokanFileInfo info)
        {
            return NtStatus.Error;
        }

        public NtStatus Unmounted(DokanFileInfo info)
        {
            return NtStatus.Success;
        }

        public NtStatus WriteFile(string fileName, byte[] buffer, out int bytesWritten, long offset, DokanFileInfo info)
        {
            byte[] file = new byte[buffer.Length];
            int i = 0;
            for (i = 0; i < buffer.Length; ++i)
                file[i] = buffer[i];
            files[fileName] = file;
            bytesWritten = i;
            return NtStatus.Success;
        }
    }
}
