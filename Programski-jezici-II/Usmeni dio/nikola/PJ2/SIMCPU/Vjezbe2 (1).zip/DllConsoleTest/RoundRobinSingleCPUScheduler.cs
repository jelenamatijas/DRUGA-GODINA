﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimCPULibrary;

namespace DllConsoleTest
{
    public class RoundRobinSingleCPUScheduler : Scheduler
    {
        Registers[] registers;
        int currentProcess = 0;

        public RoundRobinSingleCPUScheduler(CPU[] cpus, TimeSpan tick, SimulatedProgram[] programs) :
            base(cpus, tick, programs) =>
            registers = Enumerable.Repeat(new Registers(), programs.Length).ToArray();

        public override void SchedulerInterrupt()
        {
            registers[currentProcess] = cpus[0].Registers;
            int temp = currentProcess;
            while (processes[currentProcess = (currentProcess + 1) % registers.Length].Completed)
                if (currentProcess == temp)
                    return;
            cpus[0].CurrentProcess = processes[currentProcess];
            cpus[0].Registers = registers[currentProcess];
        }
    }
}
