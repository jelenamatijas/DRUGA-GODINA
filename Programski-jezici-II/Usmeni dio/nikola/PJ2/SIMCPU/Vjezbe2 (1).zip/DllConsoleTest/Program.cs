﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimCPULibrary;

namespace DllConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            CPU cpu = new CPU(0, TimeSpan.FromMilliseconds(100));
            SimulatedProgram program1 = new SimulatedProgram(new object[]
            {
                (OpCode.Mov, RegCode.B, 0),
                (OpCode.Mov, RegCode.C, -5),
                (OpCode.Mov, RegCode.A, "Sim1 "),
                (OpCode.Add, RegCode.A, RegCode.B),
                (OpCode.PrintLn),
                (OpCode.Add, RegCode.B, 1),
                (OpCode.Add, RegCode.C, 1),
                (OpCode.Jnz, 2)
            });
            SimulatedProgram program2 = new SimulatedProgram(new object[]
            {
                (OpCode.Mov, RegCode.B, 0),
                (OpCode.Mov, RegCode.C, -10),
                (OpCode.Mov, RegCode.A, "Sim2 "),
                (OpCode.Add, RegCode.A, RegCode.B),
                (OpCode.PrintLn),
                (OpCode.Add, RegCode.B, 1),
                (OpCode.Add, RegCode.C, 1),
                (OpCode.Jnz, 2)
            });

            Scheduler scheduler = new RoundRobinSingleCPUScheduler(new CPU[] { cpu }, TimeSpan.FromMilliseconds(200), new SimulatedProgram[] { program1, program2 });
            scheduler.Run();
        }
    }
}
