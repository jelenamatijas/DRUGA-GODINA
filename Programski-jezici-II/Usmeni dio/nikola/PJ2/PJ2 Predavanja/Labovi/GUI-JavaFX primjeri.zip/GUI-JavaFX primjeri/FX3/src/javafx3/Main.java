package javafx3;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author Igor
 */
public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) {
         try{
            AnchorPane page = (AnchorPane) FXMLLoader.load(getClass().getResource("Animacija.fxml"));
            Scene scene = new Scene(page);
            primaryStage.setScene(scene);
            
            primaryStage.show();
        }catch(IOException ex){
             ex.printStackTrace();
        }
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
