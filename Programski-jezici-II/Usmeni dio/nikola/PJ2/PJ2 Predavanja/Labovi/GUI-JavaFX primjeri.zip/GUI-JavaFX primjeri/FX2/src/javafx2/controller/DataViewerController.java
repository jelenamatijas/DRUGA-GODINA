/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx2.controller;

import java.awt.Dialog;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import javafx2.businessLogic.StudentUtil;
import javafx2.model.Student;
import javafx2.util.ColumnResizer;
import javafx2.util.FxmlLoader;

/**
 * FXML Controller class
 *
 * @author Igor
 */
public class DataViewerController implements Initializable {

    @FXML
    private TableColumn<Student, String> colFirstName;
    @FXML
    private TableColumn<Student, String> colLastName;
    @FXML
    private TableColumn<Student, String> colIndex;
    @FXML
    private TableColumn<Student, String> colStudyProgram;
    @FXML
    private TableColumn<Student, Integer> colStudyYear;
    @FXML
    private MenuItem menuNew;
    @FXML
    private MenuItem menuEdit;
    @FXML
    private MenuItem menuDelete;
    @FXML
    private TableView<Student> tblStudents;
    @FXML
    private ProgressBar pbProgress;

    public static ObservableList<Student> students = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            ColumnResizer.resize(new Double[]{25.0, 25.0, 15.0, 15.0, 20.0}, tblStudents);
        } catch (Exception ex) {
            Logger.getLogger(DataViewerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        colFirstName.setCellValueFactory(new PropertyValueFactory<Student, String>("firstName"));
        colIndex.setCellValueFactory(new PropertyValueFactory<Student, String>("index"));
        colLastName.setCellValueFactory(new PropertyValueFactory<Student, String>("lastName"));
        colStudyProgram.setCellValueFactory(new PropertyValueFactory<Student, String>("studyProgram"));
        colStudyYear.setCellValueFactory(new PropertyValueFactory<Student, Integer>("currentYear"));
        tblStudents.setItems(students);

        menuDelete.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                tblStudents.getItems().remove(
                        tblStudents.getSelectionModel().getSelectedItem());
            }
        });
        pbProgress.progressProperty().bind(task.progressProperty());
        new Thread(task).start();

        menuNew.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                StudentFormController.student = null;
                FxmlLoader.loadDialog(this.getClass(), "/javafx2/view/StudentForm.fxml");
            }
        });

        menuEdit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                if (tblStudents.getSelectionModel().getSelectedItem() != null) {
                    StudentFormController.student = tblStudents.getSelectionModel().getSelectedItem();
                    FxmlLoader.loadDialog(this.getClass(), "/javafx2/view/StudentForm.fxml");
                }
            }
        });

    }

    Task task = new Task() {

        @Override
        protected Object call() throws Exception {
            for (int i = 0; i < 10; i++) {
                updateProgress(i + 1, 10);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DataViewerController.class.getName()).log(Level.SEVERE, null, ex);
                }
                students.add(StudentUtil.generateRandomStudent());

            }
            return null;
        }
    };
}
