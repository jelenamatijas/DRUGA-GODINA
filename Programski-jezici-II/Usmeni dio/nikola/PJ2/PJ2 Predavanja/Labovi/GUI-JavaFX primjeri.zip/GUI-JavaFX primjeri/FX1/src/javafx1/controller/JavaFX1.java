/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx1.controller;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author Igor
 */
public class JavaFX1 extends Application {

    private final String FXML_LABEL = "FXML forma";

    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        Button btn2 = new Button("Nova forma");
        Button btn3 = new Button(FXML_LABEL);
        Button btn4 = new Button("List View");
        btn.setText("Say 'Hello World'");
        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });

        btn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                Forma f = new Forma();
                try {
                    f.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(JavaFX1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        btn3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                try{
                    Stage s = new Stage();
                    Pane myPane = (Pane)FXMLLoader.load(getClass().getResource("/javafx1/fxml/Forma1.fxml"));
                    Scene myScene = new Scene(myPane);
                    s.setScene(myScene);
                    s.show();
                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        });

        btn4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                 try{
                    Stage s = new Stage();
                    Pane myPane = (Pane)FXMLLoader.load(getClass().getResource("/javafx1/fxml/Lista.fxml"));
                    Scene myScene = new Scene(myPane);
                    s.setScene(myScene);
                    s.show();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        
        HBox root = new HBox();
        root.getChildren().add(btn);

        root.getChildren().add(btn2);

        root.getChildren().add(btn3);
        root.getChildren().add(btn4);
        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
