/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx1.controller;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Igor
 */
public class Forma extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        StackPane root = new StackPane();
        Label l = new Label("TEST");
        root.getChildren().add(l);

        Scene scene = new Scene(root, 300, 250);
        stage.setTitle("Forma!");
        stage.setScene(scene);
        stage.show();
    }

}
