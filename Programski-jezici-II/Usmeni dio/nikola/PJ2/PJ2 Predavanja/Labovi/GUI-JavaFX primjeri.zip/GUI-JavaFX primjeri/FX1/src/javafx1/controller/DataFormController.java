/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx1.controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Igor
 */
public class DataFormController implements Initializable {

    @FXML
    private TextField tfIme;
    @FXML
    private ComboBox cbBodovi;
    @FXML
    private TableView<Data> tblTabela;
    @FXML
    private TableColumn<Data, String> colIme;
    @FXML
    private TableColumn<Data, Integer> colBodovi;
    @FXML
    private Button btnDodaj;
    @FXML
    private MenuItem menuClose;
    @FXML
    private MenuItem menuDelete;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbBodovi.getItems().clear();
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i <= 100; i += 10) {
            list.add(i);
        }
        cbBodovi.getItems().addAll(list);

        //init table
        colIme.setCellValueFactory(new PropertyValueFactory<Data, String>("ime"));
        colBodovi.setCellValueFactory(new PropertyValueFactory<Data, Integer>("bodovi"));
        tblTabela.getItems().add(new Data("Test", 10));

        btnDodaj.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                if (!tfIme.getText().isEmpty() && !cbBodovi.getSelectionModel().isEmpty()) {
                    tblTabela.getItems().add(new Data(tfIme.getText(), (Integer) cbBodovi.getSelectionModel().getSelectedItem()));
                    tfIme.clear();
                    cbBodovi.getSelectionModel().clearSelection();
                }
            }
        });

        menuDelete.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                tblTabela.getItems().remove(
                        tblTabela.getSelectionModel().getSelectedItem()
                );
            }
        });

        menuClose.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                System.exit(0);
            }
        });
    }

    public class Data {

        private String ime;
        private Integer bodovi;

        public Data(String ime, Integer bodovi) {
            this.ime = ime;
            this.bodovi = bodovi;
        }

        public Data() {
        }

        public String getIme() {
            return ime;
        }

        public void setIme(String ime) {
            this.ime = ime;
        }

        public Integer getBodovi() {
            return bodovi;
        }

        public void setBodovi(Integer bodovi) {
            this.bodovi = bodovi;
        }

    }

}
