/*
 * Upotreba:
 * U kontroleru gdje se koristi:
 * ColumnResizer.resize(new Double[]{}, table);      
 */
package javafx2.util;

import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author Igor
 */
public class ColumnResizer {

    //ukupna sirina (100%)
    private final static Double TOTALSIZE = 100.0;

    /**
     * Funkcija vrsi resize kolona na procentualne vrijednosti.
     */
    public static <T> void resize(Double[] sizes, TableView<T> table) throws Exception {
        ObservableList<TableColumn<T, ?>> columns = table.getColumns();
        if (sizes.length != columns.size()) {
            throw new Exception("Missing column or width");
        }
        Double controlSum = 0.0;
        for (Double s : sizes) {
            controlSum += s;
        }
        if (!controlSum.equals(TOTALSIZE)) {
            throw new Exception("Size sum not 100%");
        }
        int i = 0;
        for (TableColumn t : columns) {
            t.prefWidthProperty().bind(table.widthProperty().divide(TOTALSIZE).multiply(sizes[i]));
            i++;
        }
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

}
