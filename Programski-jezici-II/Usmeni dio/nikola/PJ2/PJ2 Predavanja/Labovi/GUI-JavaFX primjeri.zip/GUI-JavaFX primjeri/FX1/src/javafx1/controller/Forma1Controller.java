/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx1.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Igor
 */
public class Forma1Controller implements Initializable {

    @FXML
    private TextField tfIme;
    @FXML
    private TextField tfPrezime;
    @FXML
    private Button btnOk;
    @FXML
    private Button btnTabela;
    @FXML
    private Label lblPoruka;

    @FXML
    public void okEvent() {
        lblPoruka.setText("Pozdrav: " + tfIme.getText() + " " + tfPrezime.getText());
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btnTabela.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                try {
                    Stage s = new Stage();
                    Pane myPane = (Pane) FXMLLoader.load(getClass().getResource("/javafx1/fxml/DataForm.fxml"));
                    Scene myScene = new Scene(myPane);
                    s.setScene(myScene);
                    s.show();
                } catch (IOException ex) {
                    Logger.getLogger(Forma1Controller.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

}
