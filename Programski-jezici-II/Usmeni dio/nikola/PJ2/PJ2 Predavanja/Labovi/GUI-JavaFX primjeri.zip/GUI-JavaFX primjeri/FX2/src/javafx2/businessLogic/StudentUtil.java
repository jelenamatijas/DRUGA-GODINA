/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javafx2.businessLogic;

import java.util.Date;
import java.util.Random;

import javafx2.model.Student;

/**
 *
 * @author Igor
 */
public class StudentUtil {
    private static int counter = 0;
    public static Student generateRandomStudent(){
        counter++;
        return new Student("Student"+counter, "Last Name"+counter, 
              counter+"/13", "RI", new Random().nextInt(5));
    }
}
