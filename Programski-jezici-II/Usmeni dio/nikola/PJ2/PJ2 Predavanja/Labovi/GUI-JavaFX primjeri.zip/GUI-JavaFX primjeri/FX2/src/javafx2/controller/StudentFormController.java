/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx2.controller;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx2.model.Student;

/**
 * FXML Controller class
 *
 * @author Igor
 */
public class StudentFormController implements Initializable {

    @FXML
    private TextField tfFirstName;

    @FXML
    private TextField tfLastName;

    @FXML
    private TextField tfIndex;

    @FXML
    private ComboBox<String> cbStudyProgram;

    @FXML
    private ComboBox<Integer> cbCurrentYear;

    @FXML
    private Button btnOk;

    @FXML
    private Button btnCancel;

    public static Student student = null;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbStudyProgram.setItems(FXCollections.observableArrayList("RI", "ET", "EIS"));
        cbCurrentYear.setItems(FXCollections.observableArrayList(0, 1, 2, 3, 4));

        tfIndex.setEditable(true);

        if (student != null) {
            tfIndex.setEditable(false);
            tfFirstName.setText(student.getFirstName());
            tfLastName.setText(student.getLastName());
            tfIndex.setText(student.getIndex());
            cbCurrentYear.getSelectionModel().select(student.getCurrentYear());
            cbStudyProgram.getSelectionModel().select(student.getStudyProgram());
        }

        btnCancel.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {

                Node source = (Node) t.getSource();
                Stage stage = (Stage) source.getScene().getWindow();
                stage.close();
            }
        });

        btnOk.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                if (student == null) {
                    try {
                        DataViewerController.students.add(new Student(tfFirstName.getText(), tfLastName.getText(),
                                tfIndex.getText(),
                                cbStudyProgram.getSelectionModel().getSelectedItem(),
                                cbCurrentYear.getSelectionModel().getSelectedItem()
                        ));

                    } catch (Exception ex) {
                        Logger.getLogger(StudentFormController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    student.setFirstName(tfFirstName.getText());
                    student.setLastName(tfLastName.getText());
                    student.setCurrentYear(cbCurrentYear.getSelectionModel().getSelectedItem());
                    student.setStudyProgram(cbStudyProgram.getSelectionModel().getSelectedItem());
                    final int pos = DataViewerController.students.indexOf(student);
                    DataViewerController.students.remove(student);
                    //zbog buga
                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    DataViewerController.students.add(pos, student);
                                }
                            });
                        }
                    }, 50);
                }
                Node source = (Node) t.getSource();
                Stage stage = (Stage) source.getScene().getWindow();
                stage.close();
            }
        });
    }

}
