/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx2.model;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author Igor
 */
public class Student {

    private String firstName;
    private String lastName;
    private String index;
    private String studyProgram;
    private int currentYear;

    public Student() {
    }

    public Student(String firstName, String lastName, String index, String studyProgram, int currentYear) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.index = index;
        this.studyProgram = studyProgram;
        this.currentYear = currentYear;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getStudyProgram() {
        return studyProgram;
    }

    public void setStudyProgram(String studyProgram) {
        this.studyProgram = studyProgram;
    }

    public int getCurrentYear() {
        return currentYear;
    }

    public void setCurrentYear(int currentYear) {
        this.currentYear = currentYear;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.firstName);
        hash = 71 * hash + Objects.hashCode(this.lastName);
        hash = 71 * hash + Objects.hashCode(this.index);
        hash = 71 * hash + Objects.hashCode(this.studyProgram);
        hash = 71 * hash + this.currentYear;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        
        if (!Objects.equals(this.index, other.index)) {
            return false;
        }
        
        return true;
    }

    @Override
    public String toString() {
        return "Student{" + "firstName=" + firstName + ", lastName=" + lastName + ", index=" + index + ", studyProgram=" + studyProgram + ", currentYear=" + currentYear + '}';
    }

}
