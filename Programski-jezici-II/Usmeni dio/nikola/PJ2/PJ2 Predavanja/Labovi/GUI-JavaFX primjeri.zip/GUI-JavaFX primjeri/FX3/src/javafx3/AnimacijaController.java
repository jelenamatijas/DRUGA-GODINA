/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javafx3;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Igor
 */
public class AnimacijaController implements Initializable {
    
    @FXML
    private Button btnAnim;
    @FXML //  fx:id="colBox"
    private TableColumn colBox; // Value injected by FXMLLoader

    @FXML //  fx:id="colString"
    private TableColumn colString; // Value injected by FXMLLoader

    @FXML //  fx:id="table"
    private TableView table; // Value injected by FXMLLoader
    
    private static Callback<TableColumn, TableCell> cellFactory;
    private final ObservableList<tblTest> data = FXCollections.observableArrayList(
            new tblTest(true, "Prvi1"),
            new tblTest(false, "Prvi2"),
            new tblTest(true, "Prvi3"),
            new tblTest(false, "Prvi4"),
            new tblTest(true, "Prvi5"),
            new tblTest(false, "Prvi6"),
            new tblTest(true, "Prvi7"),
            new tblTest(false, "Prvi8"),
            new tblTest(true, "Prvi9"),
            new tblTest(false, "Prvi10"),
            new tblTest(true, "Prvi11"),
            new tblTest(false, "Prvi12"),
            new tblTest(true, "Prvi13"),
            new tblTest(false, "Prvi14"),
            new tblTest(true, "Prvi15"),
            new tblTest(false, "Prvi16"),
            new tblTest(true, "Prvi17"),
            new tblTest(false, "Prvi18"),
            new tblTest(true, "Prvi19"),
            new tblTest(false, "Prvi20"),
            new tblTest(true, "Prvi21"),
            new tblTest(false, "Prvi22")
    );
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        //ANIMACIJA***********************************************************//
        btnAnim.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScaleTransition scaleTransition
                        = new ScaleTransition(Duration.millis(1000), table);
                
                scaleTransition.setToY(2f);
                scaleTransition.setCycleCount(2);
                scaleTransition.setAutoReverse(true);
                scaleTransition.play();
                
            }
        });
        
        FadeTransition fadeTransition
                = new FadeTransition(Duration.millis(1000), btnAnim);
        fadeTransition.setFromValue(1.0f);
        fadeTransition.setToValue(0.5f);
        fadeTransition.setCycleCount(Timeline.INDEFINITE);
        fadeTransition.setAutoReverse(true);
        
        TranslateTransition translateTransition
                = new TranslateTransition(Duration.millis(4000), btnAnim);
        translateTransition.setFromX(0);
        translateTransition.setToX(-350);
        translateTransition.setCycleCount(Timeline.INDEFINITE);
        translateTransition.setAutoReverse(true);
        
        RotateTransition rotateTransition
                = new RotateTransition(Duration.millis(3000), btnAnim);
        rotateTransition.setByAngle(360f);
        rotateTransition.setCycleCount(Timeline.INDEFINITE);
        rotateTransition.setAutoReverse(true);
        
        TranslateTransition translateTransitionUpDown
                = new TranslateTransition(Duration.millis(500), btnAnim);
        translateTransitionUpDown.setFromY(-40);
        translateTransitionUpDown.setToY(-5);
        translateTransitionUpDown.setCycleCount(Timeline.INDEFINITE);
        translateTransitionUpDown.setAutoReverse(true);
        
        ParallelTransition parallelTransition = new ParallelTransition();
        parallelTransition.getChildren().addAll(
                fadeTransition,
                translateTransition,
                rotateTransition,
                translateTransitionUpDown
        );
        
        parallelTransition.setCycleCount(Timeline.INDEFINITE);
        parallelTransition.play();
       //*********************************************************************//
        
        cellFactory = new Callback<TableColumn, TableCell>() {
            
            @Override
            public TableCell call(final TableColumn param) {
                final CheckBox checkBox = new CheckBox();
                final TableCell cell = new TableCell() {
                    
                    @Override
                    public void updateItem(Object item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item == null) {
                            // checkBox.setDisable(true);
                            checkBox.setSelected(false);
                        } else {
                            // checkBox.setDisable(false);
                            checkBox.setSelected(item.equals(true) ? true : false);
                            commitEdit(checkBox.isSelected() ? true : false);
                        }
                    }
                };
                cell.setGraphic(checkBox);
                return cell;
            }
        };
        colBox.setCellValueFactory(new PropertyValueFactory("check"));
        
        colBox.setCellFactory(cellFactory);
        colString.setCellValueFactory(new PropertyValueFactory("tekst"));
        table.getItems().addAll(data);
        
    }    
    
}
