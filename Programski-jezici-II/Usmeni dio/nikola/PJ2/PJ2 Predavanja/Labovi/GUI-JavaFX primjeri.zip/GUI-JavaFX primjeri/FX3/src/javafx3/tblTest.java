/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx3;

/**
 *
 * @author Igor
 */
public class tblTest {
    private Boolean check;
    private String tekst;

    public tblTest(Boolean check, String tekst) {
        this.check = check;
        this.tekst = tekst;
    }

        
    public Boolean getCheck() {
        return check;
    }

    public void setCheck(Boolean check) {
        this.check = check;
    }

    public String getTekst() {
        return tekst;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }

    @Override
    public String toString() {
        return "tblTest{" + "check=" + check + ", tekst=" + tekst + '}';
    }
    
    
}
