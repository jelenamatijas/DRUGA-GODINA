package net.etfbl.supercity.superheroes;

import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.gadgets.Gadget;
import net.etfbl.supercity.interfaces.Fly;
import net.etfbl.supercity.interfaces.RunFast;

public class Superman extends GoodCitizen implements Fly, RunFast {

	public Superman() {
		super();
		setName("Clarck Kent");
		setNickname("Superman");
		setSuperpower(true);
	}

	public Superman(String name, Integer positionX, Integer positionY) {
		super(name, positionX, positionY);
	}

	public Superman(String nickname, Gadget gadget, boolean superpower) {
		super(nickname, gadget, superpower);
	}

	@Override
	public String fly() {
		return "I am Superman and I can fly!";
	}

	@Override
	public String runFast() {
		return "I am Superman and I can run fast!";
	}

	@Override
	public String toString() {
		return "Superman [fly()=" + fly() + ", runFast()=" + runFast()
				+ ", getNickname()=" + getNickname() + ", getGadget()="
				+ getGadget() + ", getName()=" + getName()
				+ ", getPositionX()=" + getPositionX() + ", getPositionY()="
				+ getPositionY() + "]";
	}

	
}
