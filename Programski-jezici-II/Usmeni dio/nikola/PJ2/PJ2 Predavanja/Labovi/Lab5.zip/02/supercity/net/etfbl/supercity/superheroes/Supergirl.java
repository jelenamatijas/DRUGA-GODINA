package net.etfbl.supercity.superheroes;

import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.gadgets.Gadget;
import net.etfbl.supercity.interfaces.Fly;
import net.etfbl.supercity.interfaces.RunFast;

public class Supergirl extends GoodCitizen implements Fly, RunFast {

	public Supergirl() {
		super();
		setName("Kara-Zor-El");
		setNickname("Supergirl");
		setSuperpower(true);
	}

	public Supergirl(String name, Integer positionX, Integer positionY) {
		super(name, positionX, positionY);
	}

	public Supergirl(String nickname, Gadget gadget, boolean superpower) {
		super(nickname, gadget, superpower);
	}

	@Override
	public String runFast() {
		return "I am Supergirl and I can run fast!";
	}

	@Override
	public String fly() {
		return "I am Supergirl and I can fly";
	}

}
