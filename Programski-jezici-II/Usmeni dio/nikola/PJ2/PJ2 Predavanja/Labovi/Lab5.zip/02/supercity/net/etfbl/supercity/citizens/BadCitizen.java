package net.etfbl.supercity.citizens;

import java.util.Random;

public class BadCitizen extends Citizen {

	public BadCitizen() {
		super();
		setGreenKriptonyte();
		setPositionX();
		setPositionY();
	}

	public BadCitizen(boolean greenKriptonyte) {
		super();
		this.greenKriptonyte = greenKriptonyte;
	}

	private boolean greenKriptonyte;

	public boolean isGreenKriptonyte() {
		return greenKriptonyte;
	}

	public void setGreenKriptonyte() {
		Random rand = new Random();
		this.greenKriptonyte = rand.nextBoolean();
	}

	@Override
	public String toString() {
		return "BadCitizen [greenKriptonyte=" + greenKriptonyte
				+ ", getName()=" + getName() + ", getPositionX()="
				+ getPositionX() + ", getPositionY()=" + getPositionY() + "]";
	}

}
