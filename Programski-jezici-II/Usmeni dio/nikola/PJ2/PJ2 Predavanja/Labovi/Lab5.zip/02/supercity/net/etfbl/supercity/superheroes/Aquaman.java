package net.etfbl.supercity.superheroes;

import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.gadgets.Gadget;
import net.etfbl.supercity.interfaces.RunFast;
import net.etfbl.supercity.interfaces.Swim;

public class Aquaman extends GoodCitizen implements Swim, RunFast {

	public Aquaman() {
		super();
		setName("Arthur Curry");
		setNickname("Aquaman");
		setSuperpower(true);
	}

	public Aquaman(String name, Integer positionX, Integer positionY) {
		super(name, positionX, positionY);
	}

	public Aquaman(String nickname, Gadget gadget, boolean superpower) {
		super(nickname, gadget, superpower);
	}

	@Override
	public String swim() {
		return "I am Aquaman and I can swim!";
	}

	@Override
	public String runFast() {
		return "I am Aquaman and I can run fast!";
	}

}
