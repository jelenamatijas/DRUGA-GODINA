package net.etfbl.supercity.superheroes;

import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.gadgets.Gadget;
import net.etfbl.supercity.interfaces.Fly;
import net.etfbl.supercity.interfaces.RunFast;

public class WonderWoman extends GoodCitizen implements Fly, RunFast {

	public WonderWoman() {
		super();
		setName("Princess Diana of Themyscira");
		setNickname("WonderWoman");
		setSuperpower(true);
	}

	public WonderWoman(String name, Integer positionX, Integer positionY) {
		super(name, positionX, positionY);
	}

	public WonderWoman(String nickname, Gadget gadget, boolean superpower) {
		super(nickname, gadget, superpower);
	}

	@Override
	public String runFast() {
		return "I am WonderWoman and I can fly!";
	}

	@Override
	public String fly() {
		return "I am WonderWoman and I can fly!";
	}

}
