package net.etfbl.supercity.interfaces;

public interface Fly {
	public String fly();
}
