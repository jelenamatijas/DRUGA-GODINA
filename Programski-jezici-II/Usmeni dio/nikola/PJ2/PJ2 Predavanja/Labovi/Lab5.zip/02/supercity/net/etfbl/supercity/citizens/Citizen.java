package net.etfbl.supercity.citizens;

import java.util.Random;

public class Citizen {

	public Citizen()
	{
		super();
	}

	public Citizen(String name, Integer positionX, Integer positionY) {
		super();
		this.name = name;
		this.positionX = positionX;
		this.positionY = positionY;
	}

	private String name;
	private Integer positionX;
	private Integer positionY;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPositionX() {
		return positionX;
	}

	public void setPositionX() {
		Random rand = new Random();

		this.positionX = rand.nextInt(90);
	}

	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}

	public Integer getPositionY() {
		return positionY;
	}

	public void setPositionY() {
		Random rand = new Random();

		this.positionY = rand.nextInt(30);
	}

	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}

}
