package org.unibl.etf.pj2.predmet;

import org.unibl.etf.pj2.izuzetak.*;

public abstract class Predmet {
	protected double specificnaTezina;
	protected static int id;
	protected int identifikator;

	public Predmet(double specificnaTezina) {
		this.specificnaTezina = specificnaTezina;
		id++;
	}

	public abstract void print();

	public abstract void read() throws PredmetException;

	public abstract double zapremina();

	public double tezina() {
		return specificnaTezina * zapremina();
	}

	public static int poredjenje(Predmet p1, Predmet p2) {
		if (p1.zapremina() > p2.zapremina())
			return 1; // prvi je veci -> rezultat 1
		else if (p1.zapremina() < p2.zapremina())
			return -1; // drugi je veci -> rezultat -1
		else
			return 0; // ako su jednaki
	}

	/* poredjenje redefinisanjem metode equals klase Object */
	@Override
	public boolean equals(Object obj) {
		if (obj != null && obj instanceof Predmet) {
			return this.zapremina() == ((Predmet) obj).zapremina();
		}
		return false;
	}

	/* ispis redefinisanjem toString metode */
	@Override
	public String toString() {
		return "Specificna tezina: " + specificnaTezina + "\nIdentifikator: " + identifikator + "\nZapremina: "
				+ zapremina() + "\nTezina: " + tezina();
	}

}
