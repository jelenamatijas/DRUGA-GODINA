package net.etfbl.model.takmicar;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import net.etfbl.model.prepreka.Prepreka;

public class Vozac extends Takmicar implements SavladajVatruInterface {

	public Vozac(String ime) {
		super(ime);
	}
	
	@Override
	public void obradiDetaljePrepreku(Prepreka prepreka) {
		super.obradiDetaljePrepreku(prepreka);
		
		try {
			PrintWriter pw = new PrintWriter(new FileOutputStream("event.txt", true));
			pw.println("Vozac " + this.getIme() + " ne moze da savlada prepreku " + prepreka.getClass().getName());
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
