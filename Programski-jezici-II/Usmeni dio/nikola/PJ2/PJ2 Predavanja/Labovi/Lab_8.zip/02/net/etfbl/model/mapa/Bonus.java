package net.etfbl.model.mapa;

public class Bonus extends Element{

	private int vrijednost;

	public Bonus(int vrijednost) {
		super();
		this.vrijednost = vrijednost;
	}

	public int getVrijednost() {
		return vrijednost;
	}

	public void setVrijednost(int vrijednost) {
		this.vrijednost = vrijednost;
	}

}
