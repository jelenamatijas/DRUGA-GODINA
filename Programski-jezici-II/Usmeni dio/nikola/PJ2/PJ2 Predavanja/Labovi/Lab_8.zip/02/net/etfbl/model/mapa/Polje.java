package net.etfbl.model.mapa;

public class Polje {

	private Element element;

	public Polje() {
		super();
	}

	public Element getElement() {
		return element;
	}

	public void setElement(Element element) {
		this.element = element;
	}

}
