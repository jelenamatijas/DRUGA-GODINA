package net.etfbl.model.prepreka;

public class Voda extends Prepreka {

	public Voda() {
		super(2);
	}

	public void poplavi() {
		System.out.println("Voda je poplavila polje");
	}
	
}
