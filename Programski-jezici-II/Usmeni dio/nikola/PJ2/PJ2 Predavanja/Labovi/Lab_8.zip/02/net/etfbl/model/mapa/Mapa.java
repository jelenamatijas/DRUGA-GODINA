package net.etfbl.model.mapa;

import java.util.Random;

import net.etfbl.model.prepreka.Kamen;
import net.etfbl.model.prepreka.Prepreka;
import net.etfbl.model.prepreka.Vatra;
import net.etfbl.model.prepreka.Voda;

public class Mapa {

	public static final int VELICINA_MAPE = 50;

	public static Polje[] mapa = new Polje[VELICINA_MAPE];
	private Random random = new Random();
	
	public Mapa(int n, int m) {
		for(int i = 0; i<VELICINA_MAPE; i++) {
			mapa[i] = new Polje();
		}
		postaviBonuse(m);
		postaviPrepreke(n);
		System.out.println("Mapa pripremljena");
	}

	public void postaviPrepreke(int n) {
		postaviJedanTipPrepreke(n, new Voda());
		postaviJedanTipPrepreke(n, new Vatra());
		postaviJedanTipPrepreke(n, new Kamen());
	}

	private void postaviJedanTipPrepreke(int n, Prepreka p) {
		int total = 0;
		while (total < n) {
			int x = random.nextInt(VELICINA_MAPE);
			if (mapa[x].getElement() == null) {
				mapa[x].setElement(p);
				total++;
			}
		}
	}

	public void postaviBonuse(int m) {
		int total = 0;
		while (total < m) {
			int x = random.nextInt(VELICINA_MAPE);
			if (mapa[x].getElement() == null) {
				mapa[x].setElement(new Bonus(random.nextInt(3) + 2));
				total++;
			}
		}
	}

}
