package net.etfbl.model.takmicar;

public interface SavladajKamenInterface {

}
