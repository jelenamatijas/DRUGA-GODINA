package net.etfbl.model.takmicar;

public class Pje�ak extends Takmicar implements SavladajVoduInterface, SavladajKamenInterface {

	public Pje�ak(String ime) {
		super(ime);
	}
	
	@Override
	public void obradiBonus() {
		super.obradiBonus();
		setPozicija(getPozicija()+3);
	}

}
