package net.etfbl.simulacija;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import net.etfbl.model.mapa.Mapa;
import net.etfbl.model.takmicar.Pilot;
import net.etfbl.model.takmicar.Pje�ak;
import net.etfbl.model.takmicar.Takmicar;
import net.etfbl.model.takmicar.Vozac;

public class App {

	public static void main(String[] args) {

		// default vrijednosti
		int n = 5;
		int m = 5;

		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
			if ("-bonus".equals(args[i])) {
				m = Integer.valueOf(args[i + 1]);
			}

			if ("-prepreka".equals(args[i])) {
				n = Integer.valueOf(args[i + 1]);
			}
		}

		Mapa mapa = new Mapa(n, m);

		List<Takmicar> takmicari = new ArrayList<>();
		takmicari.add(new Pilot("Test pilot"));
		takmicari.add(new Pje�ak("Test pjesak"));
		takmicari.add(new Vozac("Test vozac"));

		System.out.println("Takmicari spremni");
		for (Takmicar t : takmicari) {
			t.start();
		}

		try {
			for (Takmicar t : takmicari) {
				t.join();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Svi takmicari su zavrsili kretanje");
		Collections.sort(takmicari, new Comparator<Takmicar>() {

			@Override
			public int compare(Takmicar t1, Takmicar t2) {
				return t2.getBodovi().compareTo(t1.getBodovi());
			}
		});

		System.out.println(takmicari);

	}
}
