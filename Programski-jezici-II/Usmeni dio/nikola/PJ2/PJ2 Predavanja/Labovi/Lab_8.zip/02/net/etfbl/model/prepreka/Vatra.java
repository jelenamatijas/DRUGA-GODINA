package net.etfbl.model.prepreka;

public class Vatra extends Prepreka {

	public Vatra() {
		super(3);
	}
	
	public void gori() {
		System.out.println("Vatra gori na polju");
	}

}
