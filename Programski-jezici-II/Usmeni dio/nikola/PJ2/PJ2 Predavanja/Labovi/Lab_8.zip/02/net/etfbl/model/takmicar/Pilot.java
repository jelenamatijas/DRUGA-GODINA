package net.etfbl.model.takmicar;

public class Pilot extends Takmicar implements SavladajVatruInterface, SavladajKamenInterface {

	public Pilot(String ime) {
		super(ime);
		pomjeraj = 2;
		vrijemeCekanjaPrepreke = 3000;
	}

}
