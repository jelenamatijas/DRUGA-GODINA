package net.etfbl.model.mapa;

public abstract class Element {

}
