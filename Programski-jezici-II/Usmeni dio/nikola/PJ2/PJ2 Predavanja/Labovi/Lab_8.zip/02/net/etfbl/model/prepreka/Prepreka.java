package net.etfbl.model.prepreka;

import net.etfbl.model.mapa.Element;

public abstract class Prepreka extends Element{
	
	private int jacina;

	public Prepreka(int jacina) {
		super();
		this.jacina = jacina;
	}

	public int getJacina() {
		return jacina;
	}

	public void setJacina(int jacina) {
		this.jacina = jacina;
	}
	
	
}
