package net.etfbl.model.takmicar;

import java.util.Random;

import net.etfbl.model.mapa.Bonus;
import net.etfbl.model.mapa.Mapa;
import net.etfbl.model.prepreka.Kamen;
import net.etfbl.model.prepreka.Prepreka;
import net.etfbl.model.prepreka.Vatra;
import net.etfbl.model.prepreka.Voda;

public abstract class Takmicar extends Thread {

	private String ime;
	private Integer bodovi = 0;
	private int pozicija = 0;
	protected int vrijemeCekanjaPrepreke = 2000;
	protected int pomjeraj = 1;

	private int brzina = (new Random().nextInt(1) + 1) * 1000;

	public Takmicar(String ime) {
		super();
		this.ime = ime;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public Integer getBodovi() {
		return bodovi;
	}

	public void setBodovi(Integer bodovi) {
		this.bodovi = bodovi;
	}

	public int getPozicija() {
		return pozicija;
	}

	public void setPozicija(int pozicija) {
		this.pozicija = pozicija;
	}

	@Override
	public String toString() {
		return ime + " pozicija " + pozicija + " bodovi: " + bodovi;
	}

	public void obradiBonus() {
		synchronized (Mapa.mapa[pozicija]) {
			Bonus bonus = (Bonus) Mapa.mapa[pozicija].getElement();
			bodovi += bonus.getVrijednost();
			Mapa.mapa[pozicija].setElement(null);
			System.out.println("Takmicar " + getIme() + " je pokupio bonus " + bonus.getVrijednost());
		}		
	}

	public void obradiDetaljePrepreku(Prepreka prepreka) {
		bodovi -= prepreka.getJacina();
		try {
			sleep(vrijemeCekanjaPrepreke);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		for (pozicija = 0; pozicija < Mapa.VELICINA_MAPE; pozicija += pomjeraj) {
			if (Mapa.mapa[pozicija].getElement() instanceof Bonus) {
				obradiBonus();
			} else if (Mapa.mapa[pozicija].getElement() instanceof Prepreka) {
				Prepreka prepreka = (Prepreka) Mapa.mapa[pozicija].getElement();
				if (prepreka instanceof Voda && !(this instanceof SavladajVoduInterface)) {
					((Voda) prepreka).poplavi();
					obradiDetaljePrepreku(prepreka);
				}

				if (prepreka instanceof Vatra && !(this instanceof SavladajVatruInterface)) {
					((Vatra) prepreka).gori();
					obradiDetaljePrepreku(prepreka);
				}

				if (prepreka instanceof Kamen && !(this instanceof SavladajKamenInterface)) {
					((Kamen) prepreka).obrusiSe();
					obradiDetaljePrepreku(prepreka);
				}
			} else {
				try {
					sleep(brzina);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("Takmicar " + this);

		}
		System.out.println("Takmicar " + ime + " je zavrsio kretanje");
	}

}
