package net.etfbl.model.prepreka;

public class Kamen extends Prepreka{

	public Kamen() {
		super(4);
	}
	
	public void obrusiSe() {
		System.out.println("Kamen se obrusio na polje");
	}

}
