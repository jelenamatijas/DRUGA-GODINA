package net.etfbl.pj2.interfaces;

/**
 *
 * @author igor
 */
public interface PlivanjeInterface {
    
    public Object plivanje();
    
}
