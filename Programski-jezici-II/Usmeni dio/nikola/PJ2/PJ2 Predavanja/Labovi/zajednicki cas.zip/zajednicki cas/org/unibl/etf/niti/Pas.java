package org.unibl.etf.niti;
import static org.unibl.etf.niti.Glavna.matrica;

public class Pas extends Thread{
  public String ime;
  public int vrijemeJedenja;
  public int brojReda;
  
  public Pas(String ime, int vrijemeJedenja, int brojReda){
    this.ime=ime;
    this.vrijemeJedenja=vrijemeJedenja;
    this.brojReda=brojReda;
  }
  
  @Override
  public String toString(){
    return "Pas "+ime+" jede "+vrijemeJedenja+" sekundi.";
  }
  
  @Override
  public void run(){
    for(int i=0; i<matrica[brojReda].length; i++){
      if(matrica[brojReda][i]!=null && matrica[brojReda][i].equals("hrana")){
        System.out.println("Naisli smo na hranu na poziciji ["+brojReda+", "+i+"]. "+this);
        try{
          Thread.sleep(1000*vrijemeJedenja);
        }catch(InterruptedException ex){
          ex.printStackTrace();
        }
      }
    }
  }
}