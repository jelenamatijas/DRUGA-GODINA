package org.unibl.etf.niti;
import java.util.Random;
public class Glavna{
  public static String[][] matrica=new String[4][20];
  
  public static void main(String args[]){
    //popuniti matricu hranom
    Random rand=new Random();
    for(int i=0; i<30; i++)
      matrica[rand.nextInt(4)][rand.nextInt(20)]="hrana";
    
    System.out.println("MATRICA");
    for(int i=0; i<matrica.length; i++){
      for(int j=0; j<matrica[i].length; j++){
        System.out.print(matrica[i][j]+" ");
      }
      System.out.println();
    }
    
    Pas p1=new Pas("Dzeki", 4, 0);
    Pas p2=new Pas("Siljo", 7, 1);
    Pas p3=new Pas("Pluton", 2, 2);
    Pas p4=new Pas("Lesi", 5, 3);
    
    p1.start();
    p2.start();
    p3.start();
    p4.start();
    
    try{
      p1.join();
      p2.join();
      p3.join();
      p4.join();
    }catch(InterruptedException ex){
      ex.printStackTrace();
    }
    
//kreiramo pse i postavljamo ih na odredjene pozicije i pokrecemo
    /* for(int i=0; i<4; i++)
     new Pas("Pujdo"+i, rand.nextInt(8)+2, i).start();
     
     System.out.println("Psi su zavrsili sa jedenjem.");*/
  }
}