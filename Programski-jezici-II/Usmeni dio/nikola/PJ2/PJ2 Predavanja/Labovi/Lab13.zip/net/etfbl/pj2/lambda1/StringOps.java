package net.etfbl.pj2.lambda1;

public class StringOps {

	interface StringWork {
		String operate(String a, String b);
	}

	public String operateStrings(String a, String b, StringWork sw) {
		return sw.operate(a, b);
	}

	public static void main(String[] args) {
		StringOps so = new StringOps();
		StringWork concatenation = (s1, s2) -> s1 + s2;
		StringWork concatenationUpperCase = (s1, s2) -> s1.toUpperCase() + s2.toUpperCase();
		StringWork concatenationWithCurrentNanoTime = (s1, s2) -> s1 + s2 + System.nanoTime();
		System.out.println(so.operateStrings("Java", "Advanced", concatenation));
		System.out.println(so.operateStrings("Java", "Advanced", concatenationUpperCase));
		System.out.println(so.operateStrings("Java", "Advanced", concatenationWithCurrentNanoTime));
	}

}
