package net.etfbl.pj2.knjiga;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

	public static List<Knjiga> ocitajFajl() {
		Path putanja = new File("KnjigeSpisak.csv").toPath();
		try {
			System.out.println("U fajlu KnjigeSpisak.csv ima " + Files.lines(putanja).count() + " linija.");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Stream<String> sadrzaj;
		List<Knjiga> knjige = new ArrayList<>();
		System.out.println(
				"j. Proci kroz fajl KnjigeSpisak.csv i prikazati sadrzaj fajla na konzolu klase Path i stream-ova");
		try {
			sadrzaj = Files.lines(putanja);
			sadrzaj.forEach(p -> {
				System.out.println(p);
				if (!p.contains("REDNI")) {
					String niz[] = p.split(",");
					knjige.add(new Knjiga(Integer.parseInt(niz[0]), niz[1], niz[2], Integer.parseInt(niz[3]), niz[4],
							Integer.parseInt(niz[5]), niz[6], niz[7]));
				}
			});

		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Iz fajla je kreirano " + knjige.size() + " knjiga.");
		return knjige;
	}

	public static void main(String[] args) {
		
		List<Knjiga> knjige = ocitajFajl();
		
		System.out.println("a. Knjige sortirane po naslovu u rastućem redoslijedu");
		knjige.stream()
					.sorted((x, y) -> x.getNaslov().compareTo(y.getNaslov()))
					.forEach(System.out::println);
		
		System.out.println("b. Knjige sortirane po godini objavljivanja u opadajucem redoslijedu");
		knjige.stream()
				.sorted((x, y) -> Integer.valueOf(y.getGodinaObjavljivanja())
				.compareTo(Integer.valueOf(x.getGodinaObjavljivanja())))
				.forEach(System.out::println);
		
		System.out.println("c. Knjige koje su izdane u prvoj dekadi dvijehiljadite godine");
		knjige.stream()
				.filter(p -> p.getGodinaIzdavanja() > 2000 && p.getGodinaIzdavanja() < 2010)
				.collect(Collectors.toList())
				.forEach(System.out::println);
		
		System.out.println("Unesite ime pisca po kom zelite filtrirati knjige");
		Scanner sken = new Scanner(System.in);
		String pisac = sken.nextLine();
		sken.close();
		
		System.out.println("d. Knjige koje je napisao odredjeni pisac, pri cemu se ime pisca unosi sa konzole.");
		knjige.stream()
				.filter(k -> k.getPisac()
				.contains(pisac))
				.collect(Collectors.toList())
				.forEach(System.out::println);
		
		System.out.println("e. Knjige grupisane po izdavacu");
		Map<String, List<Knjiga>> mapa = knjige.stream()
										.collect(Collectors.groupingBy(Knjiga::getIzdavac));
		System.out.println(Arrays.toString(mapa.entrySet().toArray()));
		
		System.out.println("f. Knjige koje u originalnom naslovu imaju izmedju 3 i 5 rijeci");
		knjige.stream()
				.filter(p -> p.getNaslov().split(" ").length > 3 && p.getNaslov().split(" ").length < 5)
				.collect(Collectors.toList())
				.forEach(System.out::println);
		
		System.out.println(
				"g. Koristenjem reduce metode izvrsiti sabiranje svih parnih rednih brojeva knjiga i prikazati rezultat na konzoli,");
		int suma = knjige.stream().filter(p -> p.getRedniBroj() % 2 == 0)
					.map(Knjiga::getRedniBroj)
					.collect(Collectors.toList())
					.stream()
					.reduce(0, (a, b) -> a + b);
		System.out.println("Suma parnih rednih brojeva je: " + suma);
		
		System.out.println(
				"h. Godine objavljivanja pretvoriti u mapu Integera, pa izracunati sumu svih godina djeljivih sa 3 i prikazati rezultat na konzolu");
		System.out.println("Suma godina objavljivanja djeljivih sa 3 je " + knjige.stream()
				.filter(p -> p.getGodinaObjavljivanja() % 3 == 0)
				.mapToInt(Knjiga::getGodinaObjavljivanja)
				.sum());
		
		System.out.println("i. Prikazati sva slova koja se nalaze u fajlu KnjigeSpisak.csv");
		try {
			System.out.println("Broj razlicitih slova u fajlu je " + 
						Files.lines(new File("KnjigeSpisak.csv").toPath())
						.map(line -> line.split(""))
						.flatMap(Arrays::stream)
						.distinct()
						.count()
						);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Broj razlicitih slova u fajlu je ");
		try {
			Files.lines(
					new File("Knjige.txt").toPath())
					.map(line -> line.split(""))
					.flatMap(Arrays::stream)
					.distinct()
					.forEach(System.out::print);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Prva tri elementa fajla");
		knjige.stream().limit(3).forEach(System.out::println);
	}
}
