package net.etfbl.pj2.lambda2;

@FunctionalInterface
public interface Operation {
	boolean filter(Person p);
}
