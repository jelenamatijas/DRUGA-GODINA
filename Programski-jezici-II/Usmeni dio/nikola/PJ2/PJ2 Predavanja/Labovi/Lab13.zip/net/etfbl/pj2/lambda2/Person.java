package net.etfbl.pj2.lambda2;

public class Person {
	private String firstName;
	private String lastName;
	private int age;
	private boolean hasCar;
	private boolean hasHouse;

	public Person() {
		super();
	}

	public Person(String firstName, String lastName, int age, boolean hasCar, boolean hasHouse) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.hasCar = hasCar;
		this.hasHouse = hasHouse;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isHasCar() {
		return hasCar;
	}

	public void setHasCar(boolean hasCar) {
		this.hasCar = hasCar;
	}

	public boolean isHasHouse() {
		return hasHouse;
	}

	public void setHasHouse(boolean hasHouse) {
		this.hasHouse = hasHouse;
	}

	@Override
	public String toString() {
		return firstName + " " + lastName;
	}

}
