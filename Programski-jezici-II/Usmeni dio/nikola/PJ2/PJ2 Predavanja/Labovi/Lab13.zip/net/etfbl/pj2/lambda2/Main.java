package net.etfbl.pj2.lambda2;

import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Main {

	public static void main(String[] args) {
		
		ArrayList<Person> persons = new ArrayList<>();
		persons.add(new Person("A1", "B1", 20, false, false));
		persons.add(new Person("A2", "B2", 30, true, false));
		persons.add(new Person("A3", "B3", 40, true, true));
		persons.add(new Person("A4", "B4", 50, true, true));
		persons.add(new Person("A5", "B5", 60, false, true));

		Predicate<Person> between20and40 = (person) -> person.getAge() >= 20 && person.getAge() <= 40;
		Predicate<Person> hasCar = person -> person.isHasCar();
		Predicate<Person> hasHouse = person -> person.isHasHouse();

		System.out.println("Osobe koje imaju izmedju 20 i 40 godina:");
		processPersons(persons, between20and40);
		System.out.println("Osobe koje imaju kucu:");
		processPersons(persons, hasHouse);
		System.out.println("Osobe koje imaju automobil:");
		processPersons(persons, hasCar);

		Consumer<Person> printPerson = System.out::println;
		Consumer<Person> printCustom = (p) -> System.out
				.println("Osoba " + p.getFirstName() + " " + p.getLastName() + " ima " + p.getAge() + " godina.");
		Consumer<Person> updatePersonYears = (p) -> {
			p.setAge(44);
			System.out.println("Izmjenjene godine za osobu " + p.getLastName());
		};

		System.out.println("Osobe koje imaju automobil:");
		processPersonsWithAction(persons, hasCar, printPerson);

		System.out.println("Izmjenjene godine osoba koje imaju automobil:");
		processPersonsWithAction(persons, hasCar, updatePersonYears);

		System.out.println("Godine osoba koje imaju automobil:");
		processPersonsWithAction(persons, hasCar, printCustom);
	}

	public static void processPersons(ArrayList<Person> persons, Predicate<Person> operation) {
		for (Person person : persons) {
			if (operation.test(person)) {
				System.out.println(person);
			}
		}
	}

	public static void processPersonsWithAction(ArrayList<Person> persons, Predicate<Person> operation,
			Consumer<Person> action) {
		for (Person person : persons) {
			if (operation.test(person)) {
				action.accept(person);
			}
		}
	}
}
