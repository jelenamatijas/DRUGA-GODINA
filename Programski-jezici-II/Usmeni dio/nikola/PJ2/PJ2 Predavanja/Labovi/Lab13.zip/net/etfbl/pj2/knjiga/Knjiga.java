package net.etfbl.pj2.knjiga;

public class Knjiga {

	private int redniBroj;
	private String naslov;
	private String originalniNaslov;
	private int godinaObjavljivanja;
	private String pisac;
	private int godinaIzdavanja;
	private String izdavac;
	private String datumKupovine;

	public Knjiga(int redniBroj, String naslov, String originalniNaslov, int godinaObjavljivanja, String pisac,
			int godinaIzdavanja, String izdavac, String datumKupovine) {
		super();
		this.redniBroj = redniBroj;
		this.naslov = naslov;
		this.originalniNaslov = originalniNaslov;
		this.godinaObjavljivanja = godinaObjavljivanja;
		this.pisac = pisac;
		this.godinaIzdavanja = godinaIzdavanja;
		this.izdavac = izdavac;
		this.datumKupovine = datumKupovine;
	}

	public int getRedniBroj() {
		return redniBroj;
	}

	public void setRedniBroj(int redniBroj) {
		this.redniBroj = redniBroj;
	}

	public String getNaslov() {
		return naslov;
	}

	public void setNaslov(String naslov) {
		this.naslov = naslov;
	}

	public String getOriginalniNaslov() {
		return originalniNaslov;
	}

	public void setOriginalniNaslov(String originalniNaslov) {
		this.originalniNaslov = originalniNaslov;
	}

	public int getGodinaObjavljivanja() {
		return godinaObjavljivanja;
	}

	public void setGodinaObjavljivanja(int godinaObjavljivanja) {
		this.godinaObjavljivanja = godinaObjavljivanja;
	}

	public String getPisac() {
		return pisac;
	}

	public void setPisac(String pisac) {
		this.pisac = pisac;
	}

	public int getGodinaIzdavanja() {
		return godinaIzdavanja;
	}

	public void setGodinaIzdavanja(int godinaIzdavanja) {
		this.godinaIzdavanja = godinaIzdavanja;
	}

	public String getIzdavac() {
		return izdavac;
	}

	public void setIzdavac(String izdavac) {
		this.izdavac = izdavac;
	}

	public String getDatumKupovine() {
		return datumKupovine;
	}

	public void setDatumKupovine(String datumKupovine) {
		this.datumKupovine = datumKupovine;
	}

	@Override
	public String toString() {
		return "Knjiga [redniBroj=" + redniBroj + ", naslov=" + naslov + ", originalniNaslov=" + originalniNaslov
				+ ", godinaObjavljivanja=" + godinaObjavljivanja + ", pisac=" + pisac + ", godinaIzdavanja="
				+ godinaIzdavanja + ", izdavac=" + izdavac + ", datumKupovine=" + datumKupovine + "]";
	}

}
