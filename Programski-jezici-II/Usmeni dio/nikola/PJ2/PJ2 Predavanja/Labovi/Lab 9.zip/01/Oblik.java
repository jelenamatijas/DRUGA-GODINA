abstract class Oblik{
  abstract void iscrtaj();
  abstract double povrsina();
}