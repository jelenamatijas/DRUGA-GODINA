package net.etfbl.pj2.interfaces;

/**
 *
 * @author igor
 */
public interface PenjanjeInterface {
    
    public Object penjanje();
    
}
