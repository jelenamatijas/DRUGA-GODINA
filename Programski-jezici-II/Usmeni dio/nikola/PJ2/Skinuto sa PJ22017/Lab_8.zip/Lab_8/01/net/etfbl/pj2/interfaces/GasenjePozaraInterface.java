package net.etfbl.pj2.interfaces;

/**
 *
 * @author igor
 */
public interface GasenjePozaraInterface {
    public String gasenjePozara();
}
