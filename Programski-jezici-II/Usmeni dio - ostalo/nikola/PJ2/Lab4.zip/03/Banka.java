import java.util.*;
import java.util.logging.*;
import java.io.*;

public class Banka {

	public Klijent[] klijenti = new Klijent[5];
	public static Handler handler;

	{
		try {
			// logger ce upisivati logove u fajl banka.log
			// ime logger-a je naziv klase
			handler = new FileHandler("banka.log");
			Logger.getLogger(Banka.class.getName()).addHandler(handler);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Banka() {
		for (int i = 0; i < 5; i++) {
			klijenti[i] = new Klijent("Ime" + i, "Prezime" + i, "012345678901" + i, i * 10 + 5);
		}
	}

	public static void log(Level level, String name, Exception ex) {
		Logger logger = Logger.getLogger(name);
		logger.log(level, ex.fillInStackTrace().toString());
	}

	public static void main(String[] args) {

		Banka banka = new Banka();
		Random rand = new Random();

		for (Klijent klijent : banka.klijenti) {
			System.out.println(klijent);

			try {
				klijent.umanjiStanje(rand.nextDouble() * 100);
			} catch (StanjeNaRacunuException ex) {
				log(Level.WARNING, Banka.class.getName(), ex);
			}
		}

	}
}