package org.unibl.etf.pj2.ticket;

import java.util.Scanner;
import org.unibl.etf.pj2.exceptions.DuplicateValueException;
import org.unibl.etf.pj2.exceptions.ValueException;

import java.util.Arrays;

public class Ticket {

	private int[] numbers;
	private int serialNumber;
	private static int numOfTickets;

	public Ticket() throws Exception {
		Scanner scan = new Scanner(System.in);
		numbers = new int[7];
		System.out.println("Unesite 7 brojeva:");

		for (int i = 0; i < 7; i++) {
			System.out.println((i + 1) + " broj: ");
			int temp = scan.nextInt();

			if (temp > 0 && temp <= 90) {
				for (int n : numbers) {
					if (n == temp) {
						throw new DuplicateValueException();
					}
				}
				numbers[i] = temp;
			} else {
				throw new ValueException();
			}
		}
		serialNumber = ++numOfTickets;
	}

	public int[] getNumbers() {
		return numbers;
	}

	@Override
	public String toString() {
		String numbersString = "";
		for (int n : numbers) {
			numbersString += n + " ";
		}
		return "Tiket broj: " + serialNumber + ". Brojevi: " + numbersString;
	}

	public boolean checkTicket(int[] winningNumbers) {
		Arrays.sort(winningNumbers);
		Arrays.sort(numbers);
		return Arrays.equals(winningNumbers, numbers);
	}

}
