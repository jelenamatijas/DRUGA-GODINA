﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimCPULibrary;
using SimProgram = SimCPULibrary.Program;

namespace OperativniSistemi
{
    public class Program
    {
        static void Main(string[] args)
        {
            CPU cpu = new CPU(TimeSpan.FromMilliseconds(100));
            SimProgram program = new SimProgram(new object[]
            {
                (OpCode.Mov, RegCode.A, "test"),
                (OpCode.Print),
                (OpCode.Jmp, 0)
            });
            Scheduler scheduler = new SimpleScheduler(new CPU[] { cpu }, TimeSpan.FromMilliseconds(200), new SimProgram[] { program });
            scheduler.Run();
        }
    }
}
