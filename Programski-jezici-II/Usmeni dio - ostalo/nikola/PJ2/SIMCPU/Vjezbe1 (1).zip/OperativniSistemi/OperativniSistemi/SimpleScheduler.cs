﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimCPULibrary;

namespace OperativniSistemi
{
    public class SimpleScheduler : Scheduler
    {
        public SimpleScheduler(CPU[] cpus, TimeSpan tick, SimCPULibrary.Program[] programs) :
            base(cpus, tick, programs)
        { }

        public override void SchedulerInterrupt()
        {
            cpus[0].CurrentProgram = programs[0];
        }
    }
}
