﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SimCPULibrary
{
    public class CPU
    {
        Registers registers = new Registers();
        TimeSpan tick;

        internal object locker;

        public Program CurrentProgram { get; set; }

        public Registers Registers
        {
            get => new Registers(registers);
            set => registers = new Registers(value);
        }

        public CPU(TimeSpan tick) => this.tick = tick;

        void ExecuteNextInstruction()
        {
            if (CurrentProgram == null)
                return;
            object instr = CurrentProgram[registers.IP++];
            switch (instr)
            {
                case null: break;
                case OpCode.Print:
                    Console.WriteLine(registers.A);
                    break;
                case ValueTuple<OpCode, RegCode> x when x.Item1 == OpCode.Print:
                    (_, RegCode printRegCode) = x;
                    if (printRegCode == RegCode.A)
                        Console.WriteLine(registers.A);
                    else if (printRegCode == RegCode.B)
                        Console.WriteLine(registers.B);
                    else if (printRegCode == RegCode.C)
                        Console.WriteLine(registers.C);
                    break;
                case ValueTuple<OpCode, RegCode, string> x when x.Item1 == OpCode.Mov && x.Item2 == RegCode.A:
                    (_, _, string value) = x;
                    registers.A = value;
                    break;
                case ValueTuple<OpCode, RegCode, int> x when x.Item1 == OpCode.Mov:
                    (_, RegCode code, int @int) = x;
                    if (code == RegCode.B)
                        registers.B = @int;
                    else
                        registers.C = @int;
                    break;
                case ValueTuple<OpCode, RegCode, int> x when x.Item1 == OpCode.Add:
                    (_, RegCode addRegCode, int addValue) = x;
                    switch (addRegCode)
                    {
                        case RegCode.A:
                            registers.A += addValue.ToString();
                            break;
                        case RegCode.B:
                            registers.B += addValue;
                            break;
                        case RegCode.C:
                            registers.C += addValue;
                            break;
                    }
                    break;
                case ValueTuple<OpCode, int> x when x.Item1 == OpCode.Jmp:
                    (_, int address) = x;
                    registers.IP = address;
                    break;
                default:
                    throw new NotImplementedException("The instruction is not implemented.");
            }
        }

        public Thread Run()
        {
            Thread thread = new Thread(() =>
            {
                while (true)
                {
                    Thread.Sleep(tick);
                    lock (locker)
                        ExecuteNextInstruction();
                }
            });
            thread.Start();
            return thread;
        }
    }

    public enum OpCode { Print, Add, Jmp, Mov }
    public enum RegCode { A, B, C };

    public class Registers
    {
        public string A { get; set; }
        public int B { get; set; }
        public int C { get; set; }
        public int IP { get; set; }

        public Registers(string a, int b, int c, int ip) =>
            (A, B, C, IP) = (a, b, c, ip);

        public Registers() { }

        public Registers(Registers other) :
            this(other.A, other.B, other.C, other.IP)
        { }
    }

    public class Program
    {
        public List<object> Instructions { get; } = new List<object>();

        public Program(IEnumerable<object> instructions) =>
            Instructions = instructions.ToList();

        public object this[int i] =>
            i >= 0 && i < Instructions.Count ? Instructions[i] : null;
    }

    public abstract class Scheduler
    {
        protected CPU[] cpus;
        TimeSpan tick;
        protected Program[] programs;
        object locker = new object();

        public Scheduler(CPU[] cpus, TimeSpan tick, Program[] programs) =>
            (this.cpus, this.tick, this.programs) = (cpus, tick, programs);

        public void Run()
        {
            foreach (CPU cpu in cpus)
                cpu.locker = locker;
            Thread[] cpusThreads = cpus.Select(x => x.Run()).ToArray();
            Thread schedulerThread = new Thread(() =>
            {
                while (true)
                {
                    Thread.Sleep(tick);
                    lock (locker)
                        SchedulerInterrupt();
                }
            });
            schedulerThread.Start();
            foreach (Thread thread in cpusThreads)
                thread.Join();
            schedulerThread.Join();
        }

        public abstract void SchedulerInterrupt();
    }
}
