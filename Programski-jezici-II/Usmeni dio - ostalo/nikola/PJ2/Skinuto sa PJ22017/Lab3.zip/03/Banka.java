import java.util.*;
import java.util.logging.*;
import java.io.*;

public class Banka{
  public Klijent [] klijenti = new Klijent[5];
  public static Handler handler;
  
  {
    try{
      handler = new FileHandler("lab3.log");
      Logger.getLogger("").addHandler(handler);
    }catch(IOException e){
      e.printStackTrace();
    }
  }
  
  public Banka(){
    for(int i=0; i<5; i++){
      klijenti[i] = new Klijent("Ime"+i, "Prezime"+i, "012345678901"+i, i*10+5);
    }
  }
  
  public static void main(String [] args){
    
    Banka b = new Banka();
    Random rand = new Random();
    for(int i = 0;i<b.klijenti.length;i++){
      System.out.println(b.klijenti[i]);
      try{
        b.klijenti[i].umanjiStanje(rand.nextDouble()*100);
      }catch(StanjeNaRacunuException ex){
        System.err.println(ex.getMessage());
        Logger logger= Logger.getLogger("net.etfbl");
        logger.log(Level.WARNING, "err", ex);
      }
    }
    
    
  }
}