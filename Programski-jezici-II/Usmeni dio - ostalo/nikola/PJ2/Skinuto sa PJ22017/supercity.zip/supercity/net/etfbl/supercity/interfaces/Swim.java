package net.etfbl.supercity.interfaces;

public interface Swim {
	public String swim();
}
