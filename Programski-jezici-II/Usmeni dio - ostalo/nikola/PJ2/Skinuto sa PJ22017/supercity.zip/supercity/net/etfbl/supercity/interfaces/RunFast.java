package net.etfbl.supercity.interfaces;

public interface RunFast {
	public String runFast();
}
