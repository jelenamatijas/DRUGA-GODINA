package net.etfbl.supercity.superheroes;

import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.gadgets.Gadget;

public class GreenArrow extends GoodCitizen {

	public GreenArrow() {
		super();
		setName("Oliver Queen");
		setNickname("GreenArrow");
		setSuperpower(false);
		setGadget(new Gadget("arrows"));
	}

	public GreenArrow(String nickname, Gadget gadget, boolean superpower) {
		super(nickname, gadget, superpower);
	}

	public GreenArrow(String name, Integer positionX, Integer positionY) {
		super(name, positionX, positionY);
	}

}
