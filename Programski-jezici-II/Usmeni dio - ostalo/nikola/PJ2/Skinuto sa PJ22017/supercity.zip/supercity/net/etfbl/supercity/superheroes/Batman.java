package net.etfbl.supercity.superheroes;

import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.gadgets.Gadget;
import net.etfbl.supercity.interfaces.Fly;

public class Batman extends GoodCitizen implements Fly {

	public Batman() {
		super();
		setName("Bruce Wayne");
		setNickname("Batman");
		setSuperpower(false);
		setGadget(new Gadget("batmobile"));
	}

	public Batman(String name, Integer positionX, Integer positionY) {
		super(name, positionX, positionY);
	}

	public Batman(String nickname, Gadget gadget, boolean superpower) {
		super(nickname, gadget, superpower);
	}

	@Override
	public String fly() {
		// TODO Auto-generated method stub
		return "I am Batman and I can fly!";
	}

}
