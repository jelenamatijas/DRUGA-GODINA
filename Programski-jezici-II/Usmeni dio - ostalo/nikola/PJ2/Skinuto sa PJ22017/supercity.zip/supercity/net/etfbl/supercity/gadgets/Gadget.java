package net.etfbl.supercity.gadgets;

public class Gadget {

	public Gadget() {
		super();
	}

	public Gadget(String name) {
		super();
		this.name = name;
	}

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Gadget [name=" + name + "]";
	}

}
