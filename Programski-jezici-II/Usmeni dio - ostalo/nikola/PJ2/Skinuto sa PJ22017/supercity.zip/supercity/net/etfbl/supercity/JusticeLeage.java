package net.etfbl.supercity;

import java.util.Random;

import net.etfbl.supercity.citizens.BadCitizen;
import net.etfbl.supercity.citizens.Citizen;
import net.etfbl.supercity.citizens.GoodCitizen;
import net.etfbl.supercity.superheroes.Aquaman;
import net.etfbl.supercity.superheroes.Batman;
import net.etfbl.supercity.superheroes.GreenArrow;
import net.etfbl.supercity.superheroes.Supergirl;
import net.etfbl.supercity.superheroes.Superman;
import net.etfbl.supercity.superheroes.WonderWoman;

public class JusticeLeage {

	private static String checkPosition(BadCitizen bad) {
		String position = "";
		if (bad.getPositionX() < 30) {
			position = "voda";
		} else if (bad.getPositionX() >= 30 && bad.getPositionX() < 60) {
			position = "zemlja";
		} else {
			position = "vazduh";
		}
		return position;
	}

	public static void main(String[] args) {
		// da li u gradu ima zlikovaca
		boolean isBadGuysThere = false;
		// kreiranje matrice grada
		Citizen[][] supercity = new Citizen[90][30];

		System.out.println("Postavljanje zlikovaca...");
		// postavljanje 6 zlikovaca
		BadCitizen bads[] = new BadCitizen[6];
		for (int i = 0; i < bads.length; i++) {
			bads[i] = new BadCitizen();
			bads[i].setName("bad number " + i);
			supercity[bads[i].getPositionX()][bads[i].getPositionY()] = bads[i];
			System.out.println(bads[i]);
		}

		// kreiranje superheroja
		GoodCitizen gooods[] = { new WonderWoman(), new Superman(),
				new Supergirl(), new Aquaman(), new GreenArrow(), new Batman() };

		// kreiranje generatora slucajnih brojeva
		Random rand = new Random();

		// unistavanje zlikovaca
		for (int i = 0; i < 90; i++) {
			for (int j = 0; j < 30; j++) {
				if (supercity[i][j] instanceof BadCitizen) {
					String place = JusticeLeage
							.checkPosition((BadCitizen) supercity[i][j]);
					if (place.equals("voda")) {
						System.out.println("Zlikovac "
								+ supercity[i][j].getName()
								+ " je unisten! Superheroj "
								+ gooods[3].getName());
						supercity[i][j] = gooods[3];
					} else {
						if (place.equals("zemlja")) {
							boolean sl = rand.nextBoolean();
							if (sl) { // pozivamo GreenArrow-a
								System.out.println("Zlikovac "
										+ supercity[i][j].getName()
										+ " je unisten! Superheroj "
										+ gooods[4].getName());
								supercity[i][j] = gooods[4];
							} else { // pozivamo Batman-a
								System.out.println("Zlikovac "
										+ supercity[i][j].getName()
										+ " je unisten! Superheroj "
										+ gooods[5].getName());
								supercity[i][j] = gooods[5];
							}
						} else if (place.equals("vazduh")) {
							int superhero = rand.nextInt(2); // na pozicijama od
																// 0 do 2 u nizu
																// goods su
																// heroji
																// zaduzeni za
																// vazduh
							if (superhero == 1
									&& ((BadCitizen) supercity[i][j])
											.isGreenKriptonyte()) {
								System.out.println("Superman je unisten!");
								isBadGuysThere = true;
							} else {
								System.out.println("Zlikovac "
										+ supercity[i][j].getName()
										+ " je unisten! Superheroj "
										+ gooods[superhero].getName());
								supercity[i][j] = gooods[superhero];
							}
						}
					}
				}
			}
		}

		if (!isBadGuysThere)
			System.out.println("Jusitce League je opet spasila svijet!");
		else
			System.out.println("Zlikovci su pobijedili!");

	}

}
