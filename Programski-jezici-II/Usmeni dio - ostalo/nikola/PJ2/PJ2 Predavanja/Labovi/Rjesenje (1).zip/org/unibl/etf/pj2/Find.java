package org.unibl.etf.pj2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Find {

	public static void main(String[] args) throws IOException {

		Path startingDir = Paths.get(System.getProperty("user.home"));
		String pattern = "*.txt";

		Finder finder = new Finder(pattern);
		Files.walkFileTree(startingDir, finder);
		finder.done();
	}
}