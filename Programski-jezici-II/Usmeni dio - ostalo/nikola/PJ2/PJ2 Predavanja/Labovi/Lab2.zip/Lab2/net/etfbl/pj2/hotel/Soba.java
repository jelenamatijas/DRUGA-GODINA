package net.etfbl.pj2.hotel;

/** klasa za rad sa sobama 
  * @author PJ2Asistent
  * @version 1.0 */
public class Soba{
  private int brojSprata, brojSobe, brojKreveta;
  private String opis;
  private boolean imaKlimu, imaTv, imaTelefon, imaInternet, zauzeta;
  
  public Soba() {
    this.brojSprata=1;
    this.brojKreveta=2;
    this.imaInternet=false;
    this.imaKlimu=false;
    this.imaTelefon=false;
    this.imaTv=true;
    this.opis="";
  }
  
  public Soba(int brojSprata, int brojSobe, int brojKreveta, String opis, boolean imaKlimu, boolean imaTv, boolean imaTelefon, boolean imaInternet) {
    this.brojKreveta=brojKreveta;
    this.brojSobe=brojSobe;
    this.brojSprata=brojSprata;
    this.imaInternet=imaInternet;
    this.imaKlimu=imaKlimu;
    this.imaTelefon=imaTelefon;
    this.imaTv=imaTv;
    this.opis=opis;
    this.zauzeta=false;
  }
  
  public int getBrojSprata() {
    return brojSprata;
  }
  public void setBrojSprata(int brojSprata) {
    this.brojSprata = brojSprata;
  }
  public int getBrojSobe() {
    return brojSobe;
  }
  public void setBrojSobe(int brojSobe) {
    this.brojSobe = brojSobe;
  }
  public int getBrojKreveta() {
    return brojKreveta;
  }
  public void setBrojKreveta(int brojKreveta) {
    this.brojKreveta = brojKreveta;
  }
  public String getOpis() {
    return opis;
  }
  public void setOpis(String opis) {
    this.opis = opis;
  }
  public boolean isImaKlimu() {
    return imaKlimu;
  }
  public void setImaKlimu(boolean imaKlimu) {
    this.imaKlimu = imaKlimu;
  }
  public boolean isImaTv() {
    return imaTv;
  }
  public void setImaTv(boolean imaTv) {
    this.imaTv = imaTv;
  }
  public boolean isImaTelefon() {
    return imaTelefon;
  }
  public void setImaTelefon(boolean imaTelefon) {
    this.imaTelefon = imaTelefon;
  }
  public boolean isImaInternet() {
    return imaInternet;
  }
  public void setImaInternet(boolean imaInternet) {
    this.imaInternet = imaInternet;
  }
  public boolean isZauzeta() {
    return zauzeta;
  }
  public void setZauzeta(boolean zauzeta) {
    this.zauzeta = zauzeta;
  }
}