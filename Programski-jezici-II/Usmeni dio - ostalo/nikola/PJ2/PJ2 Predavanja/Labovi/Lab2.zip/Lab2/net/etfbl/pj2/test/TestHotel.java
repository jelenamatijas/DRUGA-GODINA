package net.etfbl.pj2.test;
import net.etfbl.pj2.hotel.*;

/** klasa za test hotela 
  * @author PJ2Asistent
  * @version 1.0 */
class TestHotel{
  public static void main(String[] args) {
    Hotel h=new Hotel("ETF", "Patre 5");
    if(h.rezervisiSobu(1, 2)) System.out.println("Soba rezervisana.");
    else System.out.println("Rezervacija nije uspjela.");
    if(h.rezervisiSobu(1, 2)) System.out.println("Soba rezervisana.");
    else System.out.println("Rezervacija nije uspjela.");
    if(h.rezervisiSobu(3, 4)) System.out.println("Soba rezervisana.");
    else System.out.println("Rezervacija nije uspjela.");
    if(h.rezervisiSobu(4, 1)) System.out.println("Soba rezervisana.");
    else System.out.println("Rezervacija nije uspjela.");
    if(h.rezervisiSobu(1, 3)) System.out.println("Soba rezervisana.");
    else System.out.println("Rezervacija nije uspjela.");
    System.out.println("===============================================================================");
    System.out.println("===============================================================================");
    
    // ispis
    for(Soba s:h.getSobe()) {
      System.out.println("Broj sobe: " + s.getBrojSobe() + ", sprat: " + s.getBrojSprata());
      System.out.println("Broj kreveta: " + s.getBrojKreveta());
      System.out.println("Opis: " + s.getOpis());
      if(s.isImaTv()) System.out.println("Soba ima TV.");
      else System.out.println("Soba nema TV.");
      if(s.isImaKlimu()) System.out.println("Soba ima klimu.");
      else System.out.println("Soba nema klimu.");
      if(s.isImaTelefon()) System.out.println("Soba ima telefon.");
      else System.out.println("Soba nema telefon.");
      if(s.isImaInternet()) System.out.println("Soba ima Internet konekciju.");
      else System.out.println("Soba nema Internet konekciju.");
      if(s.isZauzeta()) System.out.println("Soba je rezervisana.");
      else System.out.println("Soba nije rezervisana.");
      System.out.println("===================================================================");
    }
  }
}