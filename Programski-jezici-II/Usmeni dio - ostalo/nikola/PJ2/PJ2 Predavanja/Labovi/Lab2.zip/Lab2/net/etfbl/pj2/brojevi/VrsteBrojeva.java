package net.etfbl.pj2.brojevi;

/** klasa za rad sa brojevima 
  * @author PJ2Asistent
  * @version 1.0 */
public class VrsteBrojeva{
  private int intervalOd;
  private int intervalDo;
  
  public VrsteBrojeva(){
    intervalOd=1;
    intervalDo=100;
  }
  
  public VrsteBrojeva(int pocetak, int kraj){
    intervalOd=pocetak;
    intervalDo=kraj;
  }
  
  /** metoda za pronalazenje prostih brojeva na zadatom intervalu*/
  public void prostBroj(){
    for (int i = intervalOd; i <= intervalDo; i++) {
      int bd = 0;
      for (int j = 1; j <= i; j++) {
        if (i % j == 0) {
          bd++;
        }
      }
      if (bd == 2) {
        System.out.println("Broj " + i + " je prost");
      }
    }
  }
  
  /** metoda za racunanje faktorijela brojeva na zadatom intervalu*/
  public void faktorijel(){
    intervalDo=10;
    for(int i=intervalOd;i<=intervalDo;i++){
      int f = 1;
      for(int j=2; j<=i; j++){
        f *= j;
      }
      System.out.println("Faktorijel broja " + i + " je " + f);
    }
  }
  
  /** metoda za pronalazenje savrsenih brojeva na zadatom intervalu*/
  public void savrsenBroj(){
    for (int i = intervalOd; i < intervalDo; i++) {
      int sumaDjelilaca = 0;
      for (int j = 1; j < i; j++) {
        if (i % j == 0) {
          sumaDjelilaca += j;
        }
      }
      if (sumaDjelilaca == i) {
        System.out.println("Broj " + i + " je savrsen.");
      }
    }
  }
  
  /** metoda za pronalazenje Armstrongovih brojeva na zadatom intervalu*/
  public void armstrongovBroj(){
    for (int i = intervalOd; i < intervalDo; i++) {
      int br = i, suma = 0;
      while (br >= 1) {
        suma += (br % 10) * (br % 10) * (br % 10);
        br = br / 10;
      }
      if (suma == i) {
        System.out.println("Broj " + i + " je Armstrongov.");
      }
    }
  }
}
