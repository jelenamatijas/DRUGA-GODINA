package net.etfbl.pj2.test;
import java.util.Scanner;

class TestScanner{  
  public static void main(String args[]){
    Scanner skener=new Scanner(System.in);
    System.out.println("Unesite vase ime:");
    String ime=skener.nextLine();
    System.out.println("Unijeli ste ime - "+ime);
  }
}