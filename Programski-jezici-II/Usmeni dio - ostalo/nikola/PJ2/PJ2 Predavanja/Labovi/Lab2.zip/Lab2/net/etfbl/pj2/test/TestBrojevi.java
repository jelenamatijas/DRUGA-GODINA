package net.etfbl.pj2.test;
import net.etfbl.pj2.brojevi.VrsteBrojeva;

/** klasa za test brojeva 
  * @author PJ2Asistent
  * @version 1.0 */
class TestBrojevi{
  public static void main(String args[]){
    VrsteBrojeva vb=new VrsteBrojeva();
    vb.prostBroj();
    vb.faktorijel();
    vb.savrsenBroj();
    vb.armstrongovBroj();
    System.out.println("*************************");
    VrsteBrojeva vb1=new VrsteBrojeva();
    vb1.prostBroj();
    vb1.faktorijel();
    vb1.savrsenBroj();
    vb1.armstrongovBroj();
  }
}