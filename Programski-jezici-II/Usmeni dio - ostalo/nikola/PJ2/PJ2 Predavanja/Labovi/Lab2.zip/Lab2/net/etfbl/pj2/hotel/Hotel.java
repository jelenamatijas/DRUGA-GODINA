package net.etfbl.pj2.hotel;

/** klasa za rad sa hotelima 
  * @author PJ2Asistent
  * @version 1.0 */
public class Hotel{
  private Soba[] sobe=new Soba[20];
  private String naziv="";
  private String adresa="";
  
  public Hotel(String naziv, String adresa) {
    this.naziv=naziv;
    this.adresa=adresa;
    for(int i=1,j=0;i<=5;i++,j+=4) {
      // u jednoj iteraciji petlje popunjavamo citav sprat
      // j oznacava redni broj sobe u nizu
      sobe[j]=new Soba(i,1,2,"Soba " + i + "1", false, true, true, true);
      sobe[j+1]=new Soba(i,2,2,"Soba " + i + "2", true, true, false, true);
      sobe[j+2]=new Soba(i,3,1,"Soba " + i + "3", false, true, true, true);
      sobe[j+3]=new Soba(i,4,2,"Soba " + i + "4", true, true, false, true);
    }
  }
  
  public int brojSlobodnihSobaNaSpratu(int sprat) {
    int brojacSoba=0;
    for(Soba s:sobe) {
      // ako je sprat jednak argumentu i soba nije zauzeta, uvecavamo brojac
      if(s.getBrojSprata()==sprat && s.isZauzeta()==false) brojacSoba++;   
    }
    return brojacSoba;
  }
  
  /**metoda za rezervaciju sobe
    * @param brojSprata broj sprata na kom se nalazi soba u hotelu
    * @param brojSobe broj sobe
    * @return potvrda o rezervaciji*/
  public boolean rezervisiSobu(int brojSprata, int brojSobe) {
    for(Soba s:sobe) {
      // ako pronadjemo sobu ciji podaci odgovaraju argumentima, provjerimo da li je zauzeta
      // ako jeste, vracamo false
      // ako nije, oznacimo ju kao zauzetu i vracamo true
      if(s.getBrojSprata()==brojSprata && s.getBrojSobe()==brojSobe) {    
        if(s.isZauzeta()) return false;
        else {
          s.setZauzeta(true);
          return true;
        }
      }
    }
    return false;
  }
  
  public Soba[] getSobe() {
    return sobe;
  }
  public void setSobe(Soba[] sobe) {
    this.sobe = sobe;
  }
  public String getNaziv() {
    return naziv;
  }
  public void setNaziv(String naziv) {
    this.naziv = naziv;
  }
  public String getAdresa() {
    return adresa;
  }
  public void setAdresa(String adresa) {
    this.adresa = adresa;
  }
}