package net.etfbl.pj2.test;
import java.util.*;

/** klasa za rad sa klasom System 
  * @author PJ2Asistent
  * @version 1.0 */
class RadSaSistemom{
  public static void main(String args[]){
    String nizOsobina[] = {"java.version", "java.home", "java.vm.name", "java.compiler", "os.name", "user.home", "java.library.path"};
    Properties osobine = System.getProperties();
    for(String osobina:nizOsobina){
      String vrijednost = osobine.getProperty(osobina);
      System.out.println(osobina+" = "+vrijednost);
    }
  }
}