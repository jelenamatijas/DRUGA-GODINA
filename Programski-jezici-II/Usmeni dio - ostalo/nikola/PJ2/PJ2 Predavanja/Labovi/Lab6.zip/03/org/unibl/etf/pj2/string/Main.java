package org.unibl.etf.pj2.string;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

public class Main {

	public static int TOTAL_STRINGS = 10000;

	public static void testString() {
		long start = System.currentTimeMillis();
		String result = "";
		int i = 0;
		while (i++ < TOTAL_STRINGS) {
			result += generateString();
		}
		// System.out.println(result);
		long end = System.currentTimeMillis();
		System.out.println(end - start);
	}

	public static void testStringBuilder() {
		long start = System.currentTimeMillis();
		StringBuilder result = new StringBuilder();
		int i = 0;
		while (i++ < TOTAL_STRINGS) {
			result.append(generateString());
		}
		// System.out.println(result.toString());
		result.toString();
		long end = System.currentTimeMillis();
		System.out.println(end - start);
	}

	public static void main(String[] args) {
		testString();
		testStringBuilder();

		for (String param : args) {
			System.out.println(param);
		}

		String dateString = "18/04/2018";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(dateString, formatter);
		Date date1 = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
		System.out.println(date);
		System.out.println(date1);

		formatter = DateTimeFormatter.ofPattern("yyyy MM dd hh:mm:ss").withZone(ZoneId.of("UTC"));
		System.out.println(formatter.format(date1.toInstant()));
	}

	public static String generateString() {
		return UUID.randomUUID().toString();
	}
}
