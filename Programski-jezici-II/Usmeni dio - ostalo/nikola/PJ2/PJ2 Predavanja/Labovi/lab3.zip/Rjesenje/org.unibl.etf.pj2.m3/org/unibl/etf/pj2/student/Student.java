package org.unibl.etf.pj2.student;

import org.unibl.etf.pj2.util.Util;

public class Student {

	private String ime;
	private String prezime;
	private Integer brojPolozenihIspita;

	public Student(String ime, String prezime, Integer brojPolozenihIspita) {
		super();
		this.ime = ime;
		this.prezime = prezime;
		this.brojPolozenihIspita = brojPolozenihIspita;
	}

	public Student() {
		super();
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public Integer getBrojPolozenihIspita() {
		return brojPolozenihIspita;
	}

	public void setBrojPolozenihIspita(Integer brojPolozenihIspita) {
		this.brojPolozenihIspita = brojPolozenihIspita;
	}

	public String getFullNameReverse() {
		return new StringBuilder(Util.concat(ime, prezime)).reverse().toString();
	}

}
