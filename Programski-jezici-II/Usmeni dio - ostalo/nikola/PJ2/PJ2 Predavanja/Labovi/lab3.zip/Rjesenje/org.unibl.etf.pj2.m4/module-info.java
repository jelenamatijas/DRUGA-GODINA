module org.unibl.etf.pj2.m4 {
	requires org.unibl.etf.pj2.m1;
	requires org.unibl.etf.pj2.m2;
	requires org.unibl.etf.pj2.m3;
	exports org.unibl.etf.pj2.main;
}

