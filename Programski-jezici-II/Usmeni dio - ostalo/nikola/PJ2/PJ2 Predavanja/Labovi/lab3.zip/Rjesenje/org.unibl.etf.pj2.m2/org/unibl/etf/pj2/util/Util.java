package org.unibl.etf.pj2.util;

import org.unibl.etf.pj2.integer.PJ2Integer;
import org.unibl.etf.pj2.string.PJ2String;

public class Util {

	public static String concat(String str1, String str2) {
		return PJ2String.toUpper(str1) + " " + PJ2String.toUpper(str2);
	}

	public static Integer reverse(Integer i1, Integer i2) {
		return PJ2Integer.reverse(i1) + PJ2Integer.reverse(i2);
	}
}
