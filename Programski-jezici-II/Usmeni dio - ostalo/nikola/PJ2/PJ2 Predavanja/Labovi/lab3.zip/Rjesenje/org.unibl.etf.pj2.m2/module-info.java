module org.unibl.etf.pj2.m2 {
	requires org.unibl.etf.pj2.m1;
	exports org.unibl.etf.pj2.util;
}

