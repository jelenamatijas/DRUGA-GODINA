package org.unibl.etf.pj2.integer;

public class PJ2Integer {

	public static String toBinaryString(Integer i) {
		return Integer.toBinaryString(i);
	}

	public static Integer reverse(Integer i) {
		return Integer.reverse(i);
	}

}
