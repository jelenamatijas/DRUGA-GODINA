package org.unibl.etf.pj2.string;

public class PJ2String {

	public static String toUpper(String str) {
		return str.toUpperCase();
	}

	public static String toLower(String str) {
		return str.toLowerCase();
	}

}
