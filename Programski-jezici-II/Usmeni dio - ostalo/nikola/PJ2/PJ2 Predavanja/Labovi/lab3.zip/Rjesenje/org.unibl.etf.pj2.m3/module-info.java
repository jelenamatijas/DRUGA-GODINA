module org.unibl.etf.pj2.m3 {
	requires org.unibl.etf.pj2.m2;
	exports org.unibl.etf.pj2.student;
}

