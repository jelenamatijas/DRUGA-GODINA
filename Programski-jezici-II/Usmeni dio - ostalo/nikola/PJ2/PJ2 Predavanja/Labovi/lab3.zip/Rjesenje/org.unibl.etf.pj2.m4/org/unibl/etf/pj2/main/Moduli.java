package org.unibl.etf.pj2.main;

import org.unibl.etf.pj2.integer.PJ2Integer;
import org.unibl.etf.pj2.student.Student;
import org.unibl.etf.pj2.util.Util;

public class Moduli {

	public static void main(String[] args) {
		Student s1 = new Student("Nikola", "Nikolic", 10);
		Student s2 = new Student("Marko", "Markovic", 20);
		
		System.out.println(s1.getFullNameReverse());
		System.out.println(s2.getFullNameReverse());
		
		System.out.println(Util.reverse(s1.getBrojPolozenihIspita(), s2.getBrojPolozenihIspita()));
		
		System.out.println(PJ2Integer.toBinaryString(s1.getBrojPolozenihIspita()));

		System.out.println(PJ2Integer.toBinaryString(s2.getBrojPolozenihIspita()));

	}

}
