package org.unibl.etf.pj2.example;

import java.util.List;

import org.unibl.etf.pj2.engine.Processor;

public class CalculateProcessor extends Processor<List<Item>, List<Item>> {

	public CalculateProcessor(int priority) {
		super(priority);
	}

	@Override
	public List<Item> process(List<Item> source) throws Exception {
		for (Item item : source) {
			item.setTotal(item.getPrice() * item.getQuantity());
		}
		return source;
	}

}
