package org.unibl.etf.pj2.example;

import java.util.ArrayList;
import java.util.List;

import org.unibl.etf.pj2.engine.Processor;

public class ParseProcessor extends Processor<List<Item>, List<String>> {

	public ParseProcessor(int priority) {
		super(priority);
	}

	@Override
	public List<Item> process(List<String> source) throws Exception {
		List<Item> result = new ArrayList<>();

		for (String s : source) {
			String[] params = s.split(",");
			result.add(new Item(params[0], 
					Double.parseDouble(params[1]), 
					Double.parseDouble(params[2]), 
					0));
		}
		return result;
	}

}
