package org.unibl.etf.pj2.example;

public class Item {

	private String name;
	private double price;
	private double quantity;
	private double total;

	public Item(String name, double price, double quantity, double total) {
		super();
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.total = total;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return name + " - kolicina: " + quantity + ", cijena: " + price + ", ukupno: " + total;
	}
}
