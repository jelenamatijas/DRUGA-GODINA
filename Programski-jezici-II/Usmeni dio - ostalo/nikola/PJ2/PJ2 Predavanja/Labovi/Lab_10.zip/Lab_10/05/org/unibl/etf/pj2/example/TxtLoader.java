package org.unibl.etf.pj2.example;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.unibl.etf.pj2.engine.Loader;

public class TxtLoader extends Loader<String> {

	public TxtLoader(int priority, String path) {
		super(priority, path);
	}

	@Override
	public List<String> load() throws Exception {
		return Files.readAllLines(Paths.get(path));
	}

}
