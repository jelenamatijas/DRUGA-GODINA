package org.unibl.etf.pj2.example;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

import org.unibl.etf.pj2.engine.Exporter;

public class TxtExporter extends Exporter<List<Item>> {

	public TxtExporter(int priority, String path) {
		super(priority, path);
	}

	@Override
	public boolean export(List<Item> data) throws Exception {
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(path)));
		for (Item item : data) {
			pw.println(item);
		}
		pw.close();
		return true;
	}

}
