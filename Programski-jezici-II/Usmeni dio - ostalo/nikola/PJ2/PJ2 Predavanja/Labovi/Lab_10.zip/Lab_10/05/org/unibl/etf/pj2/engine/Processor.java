package org.unibl.etf.pj2.engine;

public abstract class Processor<T, E> extends Engine {

	public Processor(int priority) {
		super(priority);
	}

	public abstract T process(E source) throws Exception;
}
