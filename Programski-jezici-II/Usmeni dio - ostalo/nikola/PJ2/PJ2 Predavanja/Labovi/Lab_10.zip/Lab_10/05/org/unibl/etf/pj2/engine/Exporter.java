package org.unibl.etf.pj2.engine;

public abstract class Exporter<T> extends Engine {

	protected String path;
	
	public Exporter(int priority, String path) {
		super(priority);
		this.path = path;
	}
	
	public abstract boolean export(T data) throws Exception;

}
