package org.unibl.etf.pj2.example;

import org.unibl.etf.pj2.engine.Process;

public class Main {
	
	public static void main(String[] args) {
		Object result = new Object();
		Process process = new Process(result);
		
		TxtLoader loader = new TxtLoader(100, "data.txt");
		ParseProcessor parse = new ParseProcessor(80);
		CalculateProcessor calc = new CalculateProcessor(60);
		TxtExporter save = new TxtExporter(40, "done.txt");
		
		process.addEngine(save);
		process.addEngine(parse);
		process.addEngine(loader);
		process.addEngine(calc);
		
		process.execute();
		
	}
}
