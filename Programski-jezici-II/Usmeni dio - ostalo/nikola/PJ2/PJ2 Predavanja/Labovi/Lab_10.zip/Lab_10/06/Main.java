import java.util.HashMap;

public class Main {

	public static void main(String[] args) {
		HashMap<String, Integer> stack = new HashMap<>();
		// simulacija procitanog sadrzaja
		String[] file = { "[a]=3", "(2+[a])-(4*2+(4+[a]))" };
		// obrada
		String expression = "";
		for (String line : file) {
			if (line.indexOf("[") == 0 && line.contains("=")) {
				// prvi znak je [, znaci da je deklaracija promjenljive
				String varName = line.substring(1, line.indexOf("]"));
				String varValue = line.split("=")[1]; // podrzava samo proste deklaracije
				stack.put(varName, Integer.parseInt(varValue));
				continue;
			} else if (line.contains("[") && !line.contains("=")) {
				// koristi se u izrazu
				String varName = line.substring(line.indexOf("[") + 1, line.indexOf("]"));
				//podrzava samo jednu promjenljivu u izrazu
				line = line.replaceAll("\\[" + varName + "\\]", stack.get(varName).toString());
			}
			expression += line;
		}
		System.out.print(expression + " = ");
		
		System.out.print(EvaluateString.evaluate(expression));
	}
}
