/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.etfbl.pj2.movies;

import java.util.List;
import net.etfbl.pj2.movies.forms.MoviesAsTable;
import net.etfbl.pj2.movies.utils.Movie;

/**
 *
 * @author ETFBL
 */
public class MoviesWithFileStorage {
    public static List<Movie> movies;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new MoviesAsTable().setVisible(true);
    }
    
}
