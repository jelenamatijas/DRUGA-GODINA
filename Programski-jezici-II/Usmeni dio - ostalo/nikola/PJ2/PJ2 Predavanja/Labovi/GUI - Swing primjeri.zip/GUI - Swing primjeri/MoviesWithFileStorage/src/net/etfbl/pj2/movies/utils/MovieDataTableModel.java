/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.etfbl.pj2.movies.utils;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author ETFBL
 */
public class MovieDataTableModel extends AbstractTableModel {

    private List<Movie> movies;

    public MovieDataTableModel(List<Movie> movies) {
        this.movies = movies;
    }

    @Override
    public int getRowCount() {
        return movies.size();
    }

    @Override
    public int getColumnCount() {
        return 5; //Movie has 4 properties: title, actors, genre and yearOfPublishing and the fifth one is index
    }

    @Override
    public String getColumnName(int column) {
        String name = "??";
        switch (column) {
            case 0:
                name = "Index";
                break;
            case 1:
                name = "Title";
                break;
            case 2:
                name = "Actors";
                break;
            case 3:
                name = "Genre";
                break;
            case 4:
                name = "Year of publishing";
                break;
        }
        return name;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Movie movie = movies.get(rowIndex);
        Object value = null;
        switch (columnIndex) {
            case 0:
                value = rowIndex;
                break;
            case 1:
                value = movie.getTitle();
                break;
            case 2:
                value = movie.getActors();
                break;
            case 3:
                value = movie.getGenre();
                break;
            case 4:
                value = movie.getYearOfPublishing();
                break;
        }
        return value;
    }

}
