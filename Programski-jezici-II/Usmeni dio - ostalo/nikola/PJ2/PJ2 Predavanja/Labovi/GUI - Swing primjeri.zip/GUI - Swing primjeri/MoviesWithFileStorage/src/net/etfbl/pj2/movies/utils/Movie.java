/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.etfbl.pj2.movies.utils;

import java.io.Serializable;

/**
 *
 * @author ETFBL
 */
public class Movie implements Serializable {

    private String title;
    private String actors;
    private String genre;
    private Integer yearOfPublishing;
    
    public Movie(){
        
    }

    public Movie(String title, String actors, String genre, Integer yearOfPublishing) {
        this.title = title;
        this.actors = actors;
        this.genre = genre;
        this.yearOfPublishing = yearOfPublishing;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the actors
     */
    public String getActors() {
        return actors;
    }

    /**
     * @param actors the actors to set
     */
    public void setActors(String actors) {
        this.actors = actors;
    }

    /**
     * @return the genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * @param genre the genre to set
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * @return the yearOfPublishing
     */
    public Integer getYearOfPublishing() {
        return yearOfPublishing;
    }

    /**
     * @param yearOfPublishing the yearOfPublishing to set
     */
    public void setYearOfPublishing(Integer yearOfPublishing) {
        this.yearOfPublishing = yearOfPublishing;
    }

}
