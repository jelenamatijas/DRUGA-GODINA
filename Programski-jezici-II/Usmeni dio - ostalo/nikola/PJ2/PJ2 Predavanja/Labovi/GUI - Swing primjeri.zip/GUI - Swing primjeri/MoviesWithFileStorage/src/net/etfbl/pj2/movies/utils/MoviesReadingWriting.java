/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.etfbl.pj2.movies.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ETFBL
 */
public class MoviesReadingWriting {

    public static List<Movie> addMoviesOnStart() {
        List<Movie> movies = new ArrayList<>();
        movies.add(new Movie("One Flew Over the Cuckoo's Nest", "Jack Nicholson, Louise Fletcher, Michael Berryman", "Drama", 1975));
        movies.add(new Movie("The Shawshank Redemption", "Tim Robbins, Morgan Freeman, Bob Gunton", "Crime, Drama", 1994));
        movies.add(new Movie("Fight Club", "Brad Pitt, Edward Norton, Meat Loaf", "Drama", 1999));
        movies.add(new Movie("V for Vendetta", "Hugo Weaving, Natalie Portman, Rupert Graves", "Action, Drama, Thriller", 2005));
        movies.add(new Movie("The Terminal", "Tom Hanks, Catherine Zeta-Jones, Chi McBride", "Comedy, Drama", 2004));
        movies.add(new Movie("Catch Me If You Can", "Leonardo DiCaprio, Tom Hanks, Christopher Walken", "Biography, Crime, Drama", 2002));
        movies.add(new Movie("Forrest Gump", " Tom Hanks, Robin Wright, Gary Sinise", "Drama, Romance", 1994));
        movies.add(new Movie("Inception", "Leonardo DiCaprio, Joseph Gordon-Levitt, Ellen Page", "Action, Adventure, Crime", 2010));
        movies.add(new Movie("Scent of a Woman", "Al Pacino, Chris O'Donnell, James Rebhorn", "Drama", 1992));
        movies.add(new Movie("The Jungle Book", "Neel Sethi, Bill Murray, Ben Kingsley", "Adventure, Drama, Family", 2016));
        return movies;
    }

    public static void addMoviesToSerFile(List<Movie> movies) {
        FileOutputStream fos;
        try {
            fos = new FileOutputStream("movies.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(movies);
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MoviesReadingWriting.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MoviesReadingWriting.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static List<Movie> readListFromSerFile() {
        FileInputStream fis = null;
        List<Movie> movies = null;
        try {
            fis = new FileInputStream("movies.ser");
            try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                movies = (List<Movie>) ois.readObject();
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(MoviesReadingWriting.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(MoviesReadingWriting.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fis.close();
            } catch (IOException ex) {
                Logger.getLogger(MoviesReadingWriting.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return movies;
    }
}
