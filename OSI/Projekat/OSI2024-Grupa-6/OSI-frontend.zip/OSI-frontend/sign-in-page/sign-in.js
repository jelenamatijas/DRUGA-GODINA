document.addEventListener('DOMContentLoaded', () => {
    const selected = document.querySelector('.select-selected');
    const dropdown = document.querySelector('.select-dropdown');
    const options = document.querySelectorAll('.option');

    // Otvaranje i zatvaranje dropdown-a
    selected.addEventListener('click', () => {
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    });

    // Klik na opciju
    options.forEach(option => {
        option.addEventListener('click', () => {
            selected.textContent = option.textContent; // Postavi izabranu opciju
            dropdown.style.display = 'none'; // Zatvori dropdown
        });
    });

    // Klik van dropdown-a zatvara ga
    document.addEventListener('click', (event) => {
        if (!event.target.closest('.custom-select-wrapper')) {
            dropdown.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('password');
    const togglePasswordButton = document.getElementById('togglePassword');

    togglePasswordButton.addEventListener('click', () => {
        // Proveri trenutni tip input polja
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text'; // Prikaži lozinku
            togglePasswordButton.textContent = 'Hide'; // Promeni tekst dugmeta
        } else {
            passwordInput.type = 'password'; // Sakrij lozinku
            togglePasswordButton.textContent = 'Show'; // Vrati tekst dugmeta
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const selected = document.querySelector('.select-selected');
    const dropdown = document.querySelector('.custom-select');
    const dropdownContent = document.querySelector('.select-dropdown');
    const options = document.querySelectorAll('.option'); // Sve opcije

    // Klik na selektovani deo
    selected.addEventListener('click', () => {
        if (dropdown.classList.contains('open')) {
            dropdownContent.style.height = '0'; // Postavi visinu na 0 za zatvaranje
            dropdownContent.style.padding = '0';
        } else {
            const contentHeight = dropdownContent.scrollHeight + 'px'; // Dinamička visina
            dropdownContent.style.height = contentHeight; // Postavi visinu
            dropdownContent.style.padding = '10px 0'; // Dodaj padding
        }

        // Dodaj ili ukloni klasu "open"
        dropdown.classList.toggle('open');
    });

    // Klik na opciju
    options.forEach(option => {
        option.addEventListener('click', () => {
            selected.textContent = option.textContent; // Postavi tekst izabrane opcije
            dropdownContent.style.height = '0'; // Zatvori dropdown
            dropdownContent.style.padding = '0'; // Ukloni padding
            dropdown.classList.remove('open'); // Ukloni klasu "open"
        });
    });

    // Klik van dropdown-a zatvara ga
    document.addEventListener('click', (event) => {
        if (!event.target.closest('.custom-select')) {
            dropdown.classList.remove('open');
            dropdownContent.style.height = '0'; // Zatvori dropdown
            dropdownContent.style.padding = '0'; // Ukloni padding
        }
    });
});
