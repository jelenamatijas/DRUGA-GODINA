import argparse
import os
import uuid
from datetime import datetime

import numpy as np

from dataset import MnistDataloader
from nnlib.layers import Linear, Sigmoid, Softmax
from nnlib.loss import CrossEntropyLoss
from nnlib.modules import NeuralNetwork
from nnlib.optim import SGD


def main():
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--epochs', type=int, default=40,
                           help='Number of epochs to train for.')
    argparser.add_argument('--batch-size', type=int,
                           default=10, help='Batch size.')
    argparser.add_argument('--lr', type=float, default=0.35,
                           help='Learning rate (step size). Semantics depend on optimizer.')
    argparser.add_argument('--seed', type=float, default=0,
                           help='Random seed for reproducibility.')
    argparser.add_argument('--model', type=str,
                           default=None, help='Path to model to load.')
    argparser.add_argument('--test-only', action='store_true',
                           help='Only test the model. Requires --model to be set.')
    args = argparser.parse_args()

    if args.test_only and args.model is None:
        raise ValueError('Must specify --model when using --test-only.')

    # Loading model from file is for testing only
    if args.model is not None and not args.test_only:
        raise ValueError('Must specify --test-only when using --model.')

    # Set seed for reproducibility
    np.random.seed(args.seed)

    epochs = args.epochs
    lr = args.lr
    batch_size = args.batch_size

    in_features = 28*28
    out_features = 10

    model = NeuralNetwork(
        [
            Linear(in_features, 100),
            Sigmoid(),
            Linear(100, 10),
            Sigmoid(),
            Linear(10, out_features),
            Softmax(using_cross_entropy=True)
        ])

    if args.model is not None:
        model_npz = np.load(args.model, allow_pickle=True)
        model_params = [model_npz[model_npz.files[i]]
                        for i in range(len(model_npz.files))]
        model.load(model_params)

    print('Parameter count:', model.count_parameters())

    loss_fn = CrossEntropyLoss(use_softmax=True)
    optimizer = SGD(model.parameters(), lr=lr)

    # Data
    mnist_dataloader = MnistDataloader(
        "dataset/mnist/train-images.idx3-ubyte",
        "dataset/mnist/train-labels.idx1-ubyte",
        "dataset/mnist/t10k-images.idx3-ubyte",
        "dataset/mnist/t10k-labels.idx1-ubyte"
    )

    x_train, y_train, x_test, y_test = mnist_dataloader.load_data()
    x_train, y_train = np.array(x_train), np.array(y_train)
    x_test, y_test = np.array(x_test), np.array(y_test)

    # Normalize training data
    x_train = x_train / 255.0
    x_test = x_test / 255.0

    # Convert y_train and y_test to one-hot encoding by indexing the identity matrix with y_train and y_test elements
    y_train = np.eye(10)[y_train]
    y_test = np.eye(10)[y_test]

    # Split training data into training and validation sets
    x_val = x_train[50000:]
    y_val = y_train[50000:]

    # Remove validation data from training data
    x_train = x_train[:50000]
    y_train = y_train[:50000]

    print_interval = max(x_train.shape[0] // 4 // batch_size, 1)

    if not args.test_only:
        model = train(model=model,
                      x_train=x_train,
                      y_train=y_train,
                      x_val=x_val,
                      y_val=y_val,
                      batch_size=batch_size,
                      loss_fn=loss_fn,
                      optimizer=optimizer,
                      epochs=epochs,
                      lr=lr,
                      print_interval=print_interval)

    test(model=model,
         x_test=x_test,
         y_test=y_test,
         batch_size=batch_size,
         loss_fn=loss_fn,
         print_interval=print_interval)


def train(*, model, x_train, y_train, x_val, y_val, batch_size, loss_fn, optimizer, epochs, lr, print_interval):
    # Generate session GUID and datetime string in filename-friendly format
    session_guid = str(uuid.uuid4())
    datetime_string = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    checkpoint_dir = f'checkpoints/{datetime_string}_{session_guid}'

    # Plateau schedule -- will be used to reduce learning rate when validation accuracy does not improve for a few epochs
    plateau_max_epochs = 3
    plateau_count = 0

    # Best validation accuracy so far
    best_val_accuracy = np.inf
    best_epoch = 0

    # Training loop
    for epoch in range(epochs):
        # Reset loss and misclassified count
        total_epoch_loss = 0
        total_misclassified = 0

        # Shuffle training data
        permutation = np.random.permutation(x_train.shape[0])
        x_train = x_train[permutation]
        y_train = y_train[permutation]

        for i in range(0, x_train.shape[0], batch_size):
            actual_batch_size = min(batch_size, x_train.shape[0] - i)

            # Zero gradients. Needed to clear out accumulated gradients from previous batch.
            model.zero_grad()

            # Forward pass
            y_pred = model.forward(
                x_train[i:i+actual_batch_size].reshape((actual_batch_size, -1)))
            loss = loss_fn.forward(y_pred, y_train[i:i+actual_batch_size])
            total_epoch_loss += loss

            # Backward pass
            jacob = loss_fn.backward()
            model.backward(jacob)

            # Update parameters
            optimizer.step()

            # Increase misclassified count if prediction is wrong
            total_misclassified += np.sum(np.argmax(y_pred, axis=1)
                                          != np.argmax(y_train[i:i+actual_batch_size], axis=1))

            batch_index = i // batch_size
            if batch_index % print_interval == 0:
                percent = 100 * (i + actual_batch_size) / x_train.shape[0]
                percent_misclassified = 100 * \
                    total_misclassified / (i + actual_batch_size)
                running_average_epoch_loss = total_epoch_loss / \
                    (i + actual_batch_size)
                print(
                    f'[Training] Epoch {epoch} percent=[{percent:3.0f}%] running_average_epoch_loss=[{running_average_epoch_loss:4.2f}] misclassified=[{percent_misclassified:3.2f}%]')

        percent_misclassified = 100 * total_misclassified / x_train.shape[0]
        avg_train_loss = total_epoch_loss / x_train.shape[0]
        print(
            f'[Training] avg_train_loss={avg_train_loss} misclassified={percent_misclassified:3.2f}%')

        # Validation
        total_epoch_loss = 0
        total_misclassified = 0
        for i in range(0, x_val.shape[0], batch_size):
            actual_batch_size = min(batch_size, x_val.shape[0] - i)
            y_pred = model.forward(
                x_val[i:i+actual_batch_size].reshape((actual_batch_size, -1)))
            loss = loss_fn.forward(y_pred, y_val[i:i+actual_batch_size])
            total_epoch_loss += loss

            # Increase misclassified count by the number of wrong predictions
            total_misclassified += np.sum(np.argmax(y_pred, axis=1)
                                          != np.argmax(y_val[i:i+actual_batch_size], axis=1))

            batch_index = i // batch_size
            if batch_index % print_interval == 0:
                percent = 100 * (i + actual_batch_size) / x_val.shape[0]
                percent_misclassified = 100 * \
                    total_misclassified / (i + actual_batch_size)
                running_average_epoch_loss = total_epoch_loss / \
                    (i + actual_batch_size)
                print(
                    f'[Validation] Epoch {epoch} percent=[{percent:3.0f}%] running_average_epoch_loss=[{running_average_epoch_loss:4.2f}] misclassified=[{percent_misclassified:3.2f}%]')

        percent_misclassified = 100 * total_misclassified / x_val.shape[0]
        avg_val_loss = total_epoch_loss / x_val.shape[0]
        print(
            f'[Validation] avg_val_loss={avg_val_loss} misclassified={percent_misclassified:3.2f}%')

        if percent_misclassified < best_val_accuracy:
            best_val_accuracy = percent_misclassified
            print(
                f'[Validation] New best! misclassified=[{percent_misclassified:3.2f}%]')
            plateau_count = max(plateau_count - 1, 0)
            best_epoch = epoch

            # Save model
            model_params = model.save()
            os.makedirs(checkpoint_dir, exist_ok=True)
            checkpoint_filename = os.path.join(
                checkpoint_dir, f'model_{epoch}.npz')
            np.savez(checkpoint_filename, *model_params)
        else:
            # Basic validation error plateau-based scheduling (reduce learning rate if validation loss did not improve for a few epochs)
            plateau_count += 1
            if plateau_count >= plateau_max_epochs:
                # Reduce learning rate or stop training early if learning rate is too low
                if lr <= 1e-5:
                    print(f'[Validation] Learning rate is too low. Stopping.')
                    break
                lr *= 0.1
                optimizer.lr = lr
                print(
                    f'[Validation] Validation metric did not improve. Reducing learning rate to {lr}')

    # Load best model
    checkpoint_filename = os.path.join(
        checkpoint_dir, f'model_{best_epoch}.npz')
    model_npz = np.load(checkpoint_filename, allow_pickle=True)
    best_model_params = [model_npz[model_npz.files[i]]
                         for i in range(len(model_npz.files))]
    model.load(best_model_params)

    return model


def test(*, model, x_test, y_test, batch_size, loss_fn, print_interval):
    # Test
    total_epoch_loss = 0
    total_misclassified = 0
    for i in range(0, x_test.shape[0], batch_size):
        actual_batch_size = min(batch_size, x_test.shape[0] - i)
        y_pred = model.forward(
            x_test[i:i+actual_batch_size].reshape((actual_batch_size, -1)))
        loss = loss_fn.forward(y_pred, y_test[i:i+actual_batch_size])
        total_epoch_loss += loss

        # Increase misclassified count by the number of wrong predictions
        total_misclassified += np.sum(np.argmax(y_pred, axis=1)
                                      != np.argmax(y_test[i:i+actual_batch_size], axis=1))

        batch_index = i // batch_size
        if batch_index % print_interval == 0:
            percent = 100 * (i + actual_batch_size) / x_test.shape[0]
            percent_misclassified = 100 * \
                total_misclassified / (i + actual_batch_size)
            running_average_epoch_loss = total_epoch_loss / \
                (i + actual_batch_size)
            print(
                f'[Test] percent=[{percent:3.0f}%] running_average_loss=[{running_average_epoch_loss:4.2f}] misclassified=[{percent_misclassified:3.2f}%]')

    percent_misclassified = 100 * total_misclassified / x_test.shape[0]
    avg_test_loss = total_epoch_loss / x_test.shape[0]
    print(
        f'[Test] avg_test_loss={avg_test_loss} misclassified={percent_misclassified:3.2f}%')


if __name__ == '__main__':
    main()
