import argparse
import os

import numpy as np
from PIL import Image

from nnlib.layers import Linear, Sigmoid, Softmax
from nnlib.modules import NeuralNetwork


def main():
    '''
        Predicts the digit in all images in the test_images folder.
    '''
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--model', type=str, default=None,
                           required=True, help='Path to model to load.')
    args = argparser.parse_args()

    in_features = 28*28
    out_features = 10

    model = NeuralNetwork(
        [
            Linear(in_features, 100),
            Sigmoid(),
            Linear(100, 10),
            Sigmoid(),
            Linear(10, out_features),
            Softmax(using_cross_entropy=True)
        ])

    model_npz = np.load(args.model, allow_pickle=True)
    model_params = [model_npz[model_npz.files[i]]
                    for i in range(len(model_npz.files))]
    model.load(model_params)

    test_images = os.listdir('test_images')

    for test_image in test_images:
        img = Image.open(f'test_images/{test_image}')
        img = img.convert('L')
        img = img.resize((28, 28))
        img = np.array(img)
        img = img / 255.0
        img = img.reshape((1, -1))
        y_pred = model.forward(img)
        print(f'[Test] Prediction for {test_image}: {np.argmax(y_pred)}')

    return


if __name__ == '__main__':
    main()
