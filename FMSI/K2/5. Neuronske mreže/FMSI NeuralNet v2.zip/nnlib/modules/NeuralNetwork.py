import numpy as np

class NeuralNetwork:
    ''' Neural network module. '''
    def __init__(self, layers):
        self.layers = layers

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        return x
    
    def backward(self, grad):
        for layer in reversed(self.layers):
            grad = layer.backward(grad)
        return grad
    
    def parameters(self):
        ''' Return all parameters of the network. '''
        params = []
        for layer in self.layers:
            # Check if layer has a parameters method (ensures its a method)
            if hasattr(layer, 'parameters') and callable(getattr(layer, 'parameters')):
                params.extend(layer.parameters())
        # Else if layer is an activation function, skip it.
        return params
    
    def count_parameters(self):
        ''' Return the number of parameters of the network. '''
        count = 0
        for layer in self.layers:
            if hasattr(layer, 'count_parameters') and callable(getattr(layer, 'count_parameters')):
                count += layer.count_parameters()
        return count
    
    def zero_grad(self):
        ''' Reset gradients of all parameters. '''
        for layer in self.layers:
            if hasattr(layer, 'zero_grad') and callable(getattr(layer, 'zero_grad')):
                layer.zero_grad()
    
    def save(self):
        ''' Save all parameters of the network. '''
        params = []
        for layer in self.layers:
            if hasattr(layer, 'save') and callable(getattr(layer, 'save')):
                params.extend(layer.save())
        return params
    
    def load(self, loaded_params):
        ''' Load all parameters of the network. '''
        params = self.parameters()
        for i in range(len(params)):
            np.copyto(params[i][0], loaded_params[i])