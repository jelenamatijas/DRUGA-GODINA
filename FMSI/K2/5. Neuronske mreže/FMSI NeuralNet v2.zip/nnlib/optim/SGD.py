class SGD:
    ''' Optimizer module. '''
    def __init__(self, parameters, lr, weight_decay=0.0001):
        self.parameters = parameters
        self.lr = lr
        self.weight_decay = weight_decay  # The L2 regularization coefficient

    def step(self):
        ''' Update parameters. '''
        for param_grad_pair in self.parameters:
            # Unpack the parameter and its gradient
            param, grad, apply_weight_decay = param_grad_pair

            # Apply L2 regularization: the gradient is incremented by weight_decay * param
            if apply_weight_decay:
                grad += self.weight_decay * param

            # Perform the parameter update
            param -= self.lr * grad