import numpy as np

class Linear:
    def __init__(self, input_feature_count: int, output_feature_count: int):
        # Xavier weight initialization
        limit = np.sqrt(6 / (input_feature_count + output_feature_count))
        self.W = np.random.uniform(-limit, limit, (output_feature_count, input_feature_count))

        # Initialize biases to small values
        limit /= 100
        self.b = np.random.uniform(-limit, limit, output_feature_count)

        # Cached partial derivatives of this layer's output w.r.t. its weights and biases. Used for parameter updates.
        self.jacob_w : np.ndarray = np.zeros_like(self.W)
        self.grad_b : np.ndarray = np.zeros_like(self.b)

        # Cached last input to this layer. Used for backpropagation.
        self.x : np.ndarray = None

    def forward(self, x: np.ndarray) -> np.ndarray:
        self.x = x
        return np.matmul(x, self.W.T) + self.b
    
    def backward(self, jacob : np.ndarray) -> np.ndarray:
        ''' 
        Parameters:
            jacob is a vector of partial derivatives of the propagated function w.r.t. to the output of this layer.
        
        Returns a vector of partial derivatives of the propagated function w.r.t. to the input of this layer. 
        '''

        # Chain propagated jacobian with jacobian of this layer's output w.r.t. its input.
        jacob_y = np.matmul(jacob, self.W)

        # NOTE: The gradient of the loss w.r.t. the weights and biases of this layer is accumulated -- can be accumulated over multiple batches.

        # Chain propagated jacobian with jacobian of this layer's output w.r.t. its weights and update cached jacobians.           
        self.jacob_w += np.matmul(jacob.T, self.x)

        # Chain propagated jacobian with jacobian of this layer's output w.r.t. its biases and update cached jacobians.      
        # To do this, we need to sum the propagated jacobian along the batch axis.
        self.grad_b += np.sum(jacob, axis=0)
    
        return jacob_y
    
    def parameters(self):
        return [[self.W, self.jacob_w, True], [self.b, self.grad_b, False]]
    
    def count_parameters(self):
        return self.W.size + self.b.size
    
    def zero_grad(self):
        self.jacob_w.fill(0)
        self.grad_b.fill(0)

    def save(self):
        return [self.W, self.b]
    
    def load(self, params):
        self.W, self.b = params