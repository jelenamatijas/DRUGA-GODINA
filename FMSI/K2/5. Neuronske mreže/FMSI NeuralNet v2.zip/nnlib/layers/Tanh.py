import numpy as np

class Tanh:
    ''' Tanh activation function '''
    def __init__(self):
        self.y = None

    def forward(self, x):
        self.y = np.tanh(x)
        return self.y
    
    def backward(self, grad):
        return grad * (1 - self.y**2)