import numpy as np

class ReLU:
    def __init__(self):
        self.x = None
    
    def forward(self, x):
        self.x = x
        return np.maximum(x, 0)
    
    def backward(self, grad):
        return grad * (self.x >= 0).astype(float)