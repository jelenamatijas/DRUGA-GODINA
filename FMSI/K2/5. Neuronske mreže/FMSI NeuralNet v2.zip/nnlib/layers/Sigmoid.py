import numpy as np

class Sigmoid:
    ''' Sigmoid activation funcion '''
    def __init__(self):
        self.y = None
    
    def forward(self, x):
        self.y = np.divide(1, 1 + np.exp(-x))
        return self.y
    
    def backward(self, jacob):
        return jacob * self.y * (1 - self.y)