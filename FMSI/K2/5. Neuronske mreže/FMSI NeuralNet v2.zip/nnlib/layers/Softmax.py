import numpy as np

class Softmax:
    ''' Softmax activation function '''
    def __init__(self, using_cross_entropy=False):
        self.using_cross_entropy = using_cross_entropy
        self.params = []
    
    def forward(self, x):
        # Numerically stable softmax
        # For reference, unstable variant: e_x = np.exp(x) / np.sum(np.exp(x))
        e_x = np.exp(x - np.max(x, axis=-1, keepdims=True)) # Subtract max to avoid numerical instability.
        self.y = e_x / np.sum(e_x, axis=-1, keepdims=True)
        return self.y
    
    def backward(self, jacob):
        if self.using_cross_entropy:
            return jacob
        else:
            raise NotImplementedError('Softmax backward not implemented for non-cross-entropy loss functions')
