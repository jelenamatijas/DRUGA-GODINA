from .Linear import Linear
from .Sigmoid import Sigmoid
from .Tanh import Tanh
from .ReLU import ReLU
from .Softmax import Softmax