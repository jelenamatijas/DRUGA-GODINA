import numpy as np

class MSELoss:
    ''' Mean squared error loss function '''
    def __init__(self):
        self.diff = None

    def forward(self, pred, target):
        self.diff = pred - target
        return np.mean(self.diff ** 2)
    
    def backward(self):
        return (2 / self.diff.shape[0]) * self.diff