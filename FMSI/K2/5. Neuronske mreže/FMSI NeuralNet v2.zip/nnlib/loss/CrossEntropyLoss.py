import numpy as np

class CrossEntropyLoss:
    ''' Cross entropy loss function. Useful for multi-class classification problems. '''
    def __init__(self, use_softmax=True):
        self.y_pred = None
        self.y = None
        self.use_softmax = use_softmax

    def forward(self, y_pred, y):
        self.y_pred = y_pred
        self.y = y
        self.batch_size = y_pred.shape[0]
        return -np.sum(y * np.log(y_pred + 1e-7)) / self.batch_size 
    
    def backward(self):
        if self.use_softmax:
            return (self.y_pred - self.y) / self.batch_size
        else:
            return -self.y / (self.y_pred + 1e-7) / self.batch_size