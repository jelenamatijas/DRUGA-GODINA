from .MSELoss import MSELoss
from .CrossEntropyLoss import CrossEntropyLoss