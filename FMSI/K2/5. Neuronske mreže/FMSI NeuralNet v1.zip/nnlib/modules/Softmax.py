import numpy as np

class SoftmaxWithCrossEntropy:
    def forward(self, x):
        e_x = np.exp(x - np.max(x, axis=-1, keepdims=True)) # Oduzimamo maksimum kako bi izbjegli numeričke nestabilnosti
        return e_x / np.sum(e_x, axis=-1, keepdims=True)
    
    def backward(self, grad):
        return grad