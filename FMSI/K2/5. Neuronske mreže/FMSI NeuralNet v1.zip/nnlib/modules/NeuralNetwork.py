class NeuralNetwork:
    def __init__(self, layers):
        self.layers = layers

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        return x
    
    def backward(self, grad):
        for layer in reversed(self.layers):
            grad = layer.backward(grad)
        return grad
    
    def parameters(self):
        params = []
        for layer in self.layers:
            if hasattr(layer, 'parameters') and callable(getattr(layer, 'parameters')):
                params.extend(layer.parameters())
        return params
    
    def zero_grad(self):
        for layer in self.layers:
            if hasattr(layer, 'zero_grad') and callable(getattr(layer, 'zero_grad')):
                layer.zero_grad()