import numpy as np

class Sigmoid:
    def forward(self, x):
        self.y = np.divide(1, 1 + np.exp(-x))
        return self.y
    
    def backward(self, grad):
        return grad * self.y * (1 - self.y)