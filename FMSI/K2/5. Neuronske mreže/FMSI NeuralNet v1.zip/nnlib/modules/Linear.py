import numpy as np

class Linear:
    def __init__(self, in_features: int, out_features: int):
        # Xavier weight initialization
        limit = np.sqrt(6 / (in_features + out_features))
        self.W = np.random.uniform(-limit, limit, (out_features, in_features))
        limit /= 100
        self.b = np.random.uniform(-limit, limit, out_features)

        self.grad_w = np.zeros_like(self.W)
        self.grad_b = np.zeros_like(self.b)

    def forward(self, x: np.ndarray) -> np.ndarray:
        self.x = x
        return np.matmul(x, self.W.T) + self.b
    
    def backward(self, grad : np.ndarray) -> np.ndarray:
        self.grad_w += np.matmul(grad.T, self.x)
        self.grad_b += np.sum(grad, axis=0)
        return np.matmul(grad, self.W)
    
    def parameters(self):
        return [[self.W, self.grad_w], [self.b, self.grad_b]]
    
    def zero_grad(self):
        self.grad_w.fill(0)
        self.grad_b.fill(0)