import numpy as np

class CrossEntropyLossWithSoftmax:
    def forward(self, y_pred, y):
        self.y_pred = y_pred
        self.y = y
        return -np.sum(y * np.log(y_pred + 1e-7)) / len(y)
    
    def backward(self):
        return (self.y_pred - self.y) / len(self.y)