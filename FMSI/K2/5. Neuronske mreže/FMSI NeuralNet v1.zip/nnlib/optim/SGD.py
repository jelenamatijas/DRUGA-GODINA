class SGD:
    def __init__(self, parameters, lr):
        self.parameters = parameters
        self.lr = lr

    def step(self):
        for param, grad in self.parameters:
            # NAPOMENA: Ovdje ne može da se napiše param = param - self.lr * grad,
            #           jer bi se time promijenila referenca na parametar, a ne njegova vrijednost.
            param -= self.lr * grad