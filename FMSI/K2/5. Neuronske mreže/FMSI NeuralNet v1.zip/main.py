import numpy as np

from dataset import MnistDataloader
from nnlib.modules import NeuralNetwork, Linear, Sigmoid, SoftmaxWithCrossEntropy
from nnlib.loss import CrossEntropyLossWithSoftmax
from nnlib.optim import SGD


def main():
    epochs = 5
    lr = 0.35
    batch_size = 12

    in_features = 28 * 28
    out_features = 10

    mnist_dataloader = MnistDataloader(
        "dataset/mnist/train-images.idx3-ubyte",
        "dataset/mnist/train-labels.idx1-ubyte",
        "dataset/mnist/t10k-images.idx3-ubyte",
        "dataset/mnist/t10k-labels.idx1-ubyte"
    )

    x_train, y_train, x_test, y_test = mnist_dataloader.load_data()
    x_train, y_train = np.array(x_train), np.array(y_train)
    x_test, y_test = np.array(x_test), np.array(y_test)

    x_train = x_train.reshape((x_train.shape[0], in_features))
    x_test = x_test.reshape((x_test.shape[0], in_features))

    x_train = x_train / 255.0
    x_test = x_test / 255.0

    y_train = np.eye(10)[y_train]
    y_test = np.eye(10)[y_test]

    model = NeuralNetwork(
        [
            Linear(in_features, 100),
            Sigmoid(),
            Linear(100, 10),
            Sigmoid(),
            Linear(10, out_features),
            SoftmaxWithCrossEntropy()
        ])

    loss_fn = CrossEntropyLossWithSoftmax()
    optimizer = SGD(model.parameters(), lr=lr)

    for epoch in range(epochs):
        total_misclassified = 0

        # Miješamo podatke prije svake epohe, tako da su u svakoj epohi podaci u drugačijem redoslijedu
        permutation = np.random.permutation(x_train.shape[0])
        x_train = x_train[permutation]
        y_train = y_train[permutation]

        for i in range(0, x_train.shape[0], batch_size):
            model.zero_grad()

            x = x_train[i:i+batch_size]
            y = y_train[i:i+batch_size]

            y_pred = model.forward(x)

            loss = loss_fn.forward(y_pred, y)

            grad = loss_fn.backward()
            model.backward(grad)
            optimizer.step()

            total_misclassified += np.sum(np.argmax(y_pred, axis=1) != np.argmax(y, axis=1))

            if i % (batch_size * 1000) == 0:
                print(f'[Training] epoch={epoch} batch={i//batch_size:4}/{x_train.shape[0]//batch_size} loss={loss:.2f}')

        percent_misclassified = 100 * total_misclassified / x_train.shape[0]
        print(f'[Training] epoch={epoch} misclassified={percent_misclassified:3.2f}%')

    # Test
    total_misclassified = 0
    batch_size = 1000
    for i in range(0, x_test.shape[0], batch_size):
        x = x_test[i:i+batch_size]
        y = y_test[i:i+batch_size]
        y_pred = model.forward(x)
        total_misclassified += np.sum(np.argmax(y_pred, axis=1) != np.argmax(y, axis=1))

    percent_misclassified = 100 * total_misclassified / x_test.shape[0]
    print(f'[Test] misclassified={percent_misclassified:3.2f}%')

if __name__ == '__main__':
    main()
