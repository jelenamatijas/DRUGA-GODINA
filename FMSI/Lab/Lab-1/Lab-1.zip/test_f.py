import f

def test_f_100_to_10():
    assert f.f(100) == 10

def test_f_95_to_10():
    assert f.f(95) == 10

def test_f_91_to_10():
    assert f.f(91) == 10

def test_f_90_to_9():
    assert f.f(90) == 9

def test_f_85_to_9():
    assert f.f(85) == 9

def test_f_81_to_9():
    assert f.f(81) == 9

def test_f_80_to_8():
    assert f.f(80) == 8

def test_f_75_to_8():
    assert f.f(75) == 8

def test_f_71_to_8():
    assert f.f(71) == 8

def test_f_70_to_7():
    assert f.f(70) == 7

def test_f_65_to_7():
    assert f.f(65) == 7

def test_f_61_to_7():
    assert f.f(61) == 7

def test_f_60_to_6():
    assert f.f(60) == 6

def test_f_55_to_6():
    assert f.f(55) == 6

def test_f_51_to_6():
    assert f.f(51) == 6

def test_f_40_to_5():
    assert f.f(40) == 5

def test_f_101_to_10():
    assert f.f(101) == 10