#pragma once

#include "Point.h"

class Stack {
private:
  Point *data;
  int capacity;
  int topIndex;

public:
  Stack();
  Stack(int initialCapacity = 10);
  ~Stack();

  void push(Point &value);
  void pop();
  Point &top();
  bool isEmpty();
  int size();

private:
  void resize(int newCapacity);
};
