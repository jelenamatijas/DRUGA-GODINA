#pragma once

class Point {

private:
  const int x;
  const int y;

  Point(int x = 0, int y = 0);

public:
  int getX();
  int getY();
};
